#SXD20|20011|50168|50322|2013.09.27 13:51:47|sachs|utf8|118|979|
#TA oc_address`26`3304|oc_affiliate`0`0|oc_affiliate_transaction`0`0|oc_attribute`0`0|oc_attribute_description`0`0|oc_attribute_group`0`0|oc_attribute_group_description`0`0|oc_banner`0`0|oc_banner_image`0`0|oc_banner_image_description`0`0|oc_category`23`772|oc_category_description`23`1320|oc_category_filter`0`0|oc_category_path`56`728|oc_category_to_layout`0`0|oc_category_to_store`23`207|oc_country`1`32|oc_coupon`3`208|oc_coupon_category`0`0|oc_coupon_history`0`0|oc_coupon_product`0`0|oc_currency`2`96|oc_custom_field`0`0|oc_custom_field_description`0`0|oc_custom_field_to_customer_group`0`0|oc_custom_field_value`0`0|oc_custom_field_value_description`0`0|oc_customer`25`4484|oc_customer_ban_ip`0`0|oc_customer_field`0`0|oc_customer_group`1`29|oc_customer_group_description`1`36|oc_customer_history`0`0|oc_customer_ip`58`2072|oc_customer_ip_blacklist`0`0|oc_customer_online`0`16384|oc_customer_reward`0`0|oc_customer_transaction`0`0|oc_download`0`0|oc_download_description`0`0|oc_extension`18`440|oc_filter`0`0|oc_filter_description`0`0|oc_filter_group`0`0|oc_filter_group_description`0`0|oc_geo_zone`0`0|oc_information`3`42|oc_information_description`3`8176|oc_information_to_layout`0`0|oc_information_to_store`3`27|oc_language`1`80|oc_layout`11`224|oc_layout_route`9`256|oc_length_class`3`39|oc_length_class_description`3`108|oc_manufacturer`4`80|oc_manufacturer_to_store`3`27|oc_option`11`232|oc_option_description`11`244|oc_option_value`14`280|oc_option_value_description`14`348|oc_order`73`53980|oc_order_download`0`0|oc_order_field`0`0|oc_order_fraud`0`0|oc_order_history`22`6904|oc_order_misc`0`0|oc_order_option`0`0|oc_order_product`77`6064|oc_order_recurring`0`0|oc_order_recurring_transaction`0`0|oc_order_status`7`248|oc_order_total`221`22792|oc_order_voucher`0`0|oc_product`0`598972|oc_product_attribute`0`0|oc_product_description`0`432976|oc_product_discount`0`0|oc_product_filter`0`0|oc_product_image`0`0|oc_product_option`0`0|oc_product_option_value`0`0|oc_product_profile`0`0|oc_product_recurring`0`0|oc_product_related`0`0|oc_product_reward`0`17|oc_product_special`0`0|oc_product_tag`0`0|oc_product_to_category`0`34236|oc_product_to_download`0`0|oc_product_to_layout`0`13|oc_product_to_store`0`5175|oc_profile`0`0|oc_profile_description`0`0|oc_return`0`0|oc_return_action`3`84|oc_return_history`0`0|oc_return_reason`3`152|oc_return_status`3`76|oc_review`0`0|oc_setting`163`19992|oc_stock_status`5`196|oc_store`0`0|oc_tax_class`0`0|oc_tax_rate`1`60|oc_tax_rate_to_customer_group`1`9|oc_tax_rule`0`0|oc_url_alias`4`137760|oc_user`4`524|oc_user_group`3`10224|oc_voucher`0`0|oc_voucher_history`0`0|oc_voucher_theme`3`120|oc_voucher_theme_description`3`68|oc_weight_class`4`52|oc_weight_class_description`2`68|oc_zone`24`1288|oc_zone_to_geo_zone`0`0
#EOH

#	TC`oc_address`utf8_bin	;
CREATE TABLE `oc_address` (
  `address_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `firstname` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `lastname` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `company` varchar(32) COLLATE utf8_bin NOT NULL,
  `company_id` varchar(32) COLLATE utf8_bin NOT NULL,
  `tax_id` varchar(32) COLLATE utf8_bin NOT NULL,
  `address_1` varchar(128) COLLATE utf8_bin NOT NULL,
  `address_2` varchar(128) COLLATE utf8_bin NOT NULL,
  `city` varchar(128) COLLATE utf8_bin NOT NULL,
  `postcode` varchar(10) COLLATE utf8_bin NOT NULL,
  `country_id` int(11) NOT NULL DEFAULT '0',
  `zone_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`address_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TD`oc_address`utf8_bin	;
INSERT INTO `oc_address` VALUES 
(2,2,'Александр Алексеевич','Борщенко','Автосклад-Эксперт','','','пр-т Краснозвездный 99','','Киев','',220,3490),
(3,3,'Александр','РР','','','','пр.Героев Сталинграда','','Севастополь','99059',220,3483),
(4,4,'Виталий Олегович','Колинко','Магазины &quot;Гараж&quot;','','','пр.Ленина 62','Б-р Строителей 29','г.Днепродзержинск','',220,3484),
(5,5,'Михаил','Гломозда','СТО &quot;Азовье&quot;','','','ул.Латышева 58','','Мариуполь','',220,3485),
(6,6,'Віталій Володимирович','Мищишин','','','','с. Йосипівка','','Козова','',220,3500),
(7,7,'Артур Александрович','Мороз','pitStop','','','ул.Мира 10','','Лисичанск','93100',220,3492),
(8,8,'Николай','Бабюк','','','','Буковинская 7','','Вертянка','60214',220,3482),
(9,9,'Сергей Леонидович','Недавний','СТО','','','.ул.Егорова ','53а','Светловодск','27500',220,3489),
(10,10,'Аннаби','Осама','','','','Ленина, 165','','Луганск','91055',220,3492),
(11,11,'Игорь','Кенич','','','','ул. Мира 1','','Дружковка','',220,3485),
(12,12,'Сергей Анатольевич','Пиган','','','','ул. Мира 26, кв. 60','','Херсон','73000',220,3494),
(15,13,'Дмитрий','Зубенко','evropa parts','','','Бакинская 35','','Киев','',220,3490),
(14,8,'Рувим Николаевич','Бабюк','Новая почта скл № 4','','','Головна 200','','г.Черновцы','60214',220,3482),
(16,14,'денис михайлович','лазаренко','','','','50 лет октября','','кривой рог','',220,3484),
(17,15,'Микола Олегович','Любчак','','','','Кавалерідзе 21\\36','','Львів','',220,3493),
(18,16,'Александр','Езерский','','','','Карбышева 2а/1','','Луцк','',220,3502),
(19,17,'Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023',220,3502),
(20,18,'Олег Валериевич','Лановенко','','','','пер. Кияновский 3-7, оф. 202.','','Киев','',220,3490),
(21,19,'Святослав Олегович','Пальчиков','Оливия','','','г. Николаев ул. Буденого 42','','Николаев','',220,3494),
(22,20,'Сергей','Захаренко','','','','Челябинская, 2','','Киев','',220,3490),
(23,21,'Дмитрий','Демиденко','ЧП Федоренко','','','ул Некрасова 82а','','Херсон','73000',220,3488),
(24,22,'игор','дрожак','чп титова','','','житомир','ул.Б.тена 18','житомир','',220,3505),
(25,23,'Сергей Михайлович','Секеда','ООО &quot;Гаммапромсервис&quot;','','','г. Харьков, ','ул. Ильинская 59, 155','г. Харьков','61093',220,3487),
(26,24,'Евгений Владимирович','Рева','','','','Зелёная','','Кременчуг','39600',220,3496),
(27,25,'Евгений Владимирович','Соловьёв','Новая почта','','','Шкрумеляка 6а','','Коломыя','78200',220,3486),
(28,26,'алексеенко','максим','автомаксимум','','','винница','винница','винница','21034',220,3501)	;
#	TC`oc_affiliate`utf8_general_ci	;
CREATE TABLE `oc_affiliate` (
  `affiliate_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `email` varchar(96) NOT NULL,
  `telephone` varchar(32) NOT NULL,
  `fax` varchar(32) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(9) NOT NULL,
  `company` varchar(32) NOT NULL,
  `website` varchar(255) NOT NULL,
  `address_1` varchar(128) NOT NULL,
  `address_2` varchar(128) NOT NULL,
  `city` varchar(128) NOT NULL,
  `postcode` varchar(10) NOT NULL,
  `country_id` int(11) NOT NULL,
  `zone_id` int(11) NOT NULL,
  `code` varchar(64) NOT NULL,
  `commission` decimal(4,2) NOT NULL DEFAULT '0.00',
  `tax` varchar(64) NOT NULL,
  `payment` varchar(6) NOT NULL,
  `cheque` varchar(100) NOT NULL,
  `paypal` varchar(64) NOT NULL,
  `bank_name` varchar(64) NOT NULL,
  `bank_branch_number` varchar(64) NOT NULL,
  `bank_swift_code` varchar(64) NOT NULL,
  `bank_account_name` varchar(64) NOT NULL,
  `bank_account_number` varchar(64) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `approved` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`affiliate_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_affiliate_transaction`utf8_general_ci	;
CREATE TABLE `oc_affiliate_transaction` (
  `affiliate_transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`affiliate_transaction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_attribute`utf8_bin	;
CREATE TABLE `oc_attribute` (
  `attribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_group_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`attribute_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_attribute_description`utf8_bin	;
CREATE TABLE `oc_attribute_description` (
  `attribute_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(64) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`attribute_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_attribute_group`utf8_bin	;
CREATE TABLE `oc_attribute_group` (
  `attribute_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`attribute_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_attribute_group_description`utf8_bin	;
CREATE TABLE `oc_attribute_group_description` (
  `attribute_group_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(64) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`attribute_group_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_banner`utf8_bin	;
CREATE TABLE `oc_banner` (
  `banner_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_bin NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`banner_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_banner_image`utf8_bin	;
CREATE TABLE `oc_banner_image` (
  `banner_image_id` int(11) NOT NULL AUTO_INCREMENT,
  `banner_id` int(11) NOT NULL,
  `link` varchar(255) COLLATE utf8_bin NOT NULL,
  `image` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`banner_image_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_banner_image_description`utf8_bin	;
CREATE TABLE `oc_banner_image_description` (
  `banner_image_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `banner_id` int(11) NOT NULL,
  `title` varchar(64) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`banner_image_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_category`utf8_bin	;
CREATE TABLE `oc_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `top` tinyint(1) NOT NULL,
  `column` int(3) NOT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=47	;
#	TD`oc_category`utf8_bin	;
INSERT INTO `oc_category` VALUES 
(13,'',0,0,0,9,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(25,'data/boge_logo.gif',0,0,0,2,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(26,'',25,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(27,'data/sachs_logo.gif',0,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(10,'',27,0,0,1,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(7,'',10,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(8,'',10,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(12,'',10,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(15,'',10,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(19,'',10,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(23,'',10,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(11,'',27,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(5,'',11,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(6,'',11,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(14,'',11,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(16,'',11,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(17,'',11,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(18,'',11,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(20,'',11,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(21,'',11,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(22,'',11,0,0,0,0,'2012-10-10 12:37:51','2012-11-17 15:07:38'),
(3,\N,0,0,0,1,1,'2012-12-04 11:26:51','2013-06-18 13:15:37'),
(4,\N,0,0,0,2,1,'2012-12-04 11:26:51','2013-06-18 13:15:37')	;
#	TC`oc_category_description`utf8_bin	;
CREATE TABLE `oc_category_description` (
  `category_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `description` text COLLATE utf8_bin NOT NULL,
  `meta_description` varchar(255) COLLATE utf8_bin NOT NULL,
  `meta_keyword` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`category_id`,`language_id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=74	;
#	TD`oc_category_description`utf8_bin	;
INSERT INTO `oc_category_description` VALUES 
(13,2,'Прочее','&lt;br /&gt;\r\n','',''),
(26,2,'Амортизаторы','&lt;br /&gt;\r\n','',''),
(10,2,'Сцепление','&lt;br /&gt;\r\n','',''),
(7,2,'Диски сцепления','&lt;br /&gt;\r\n','',''),
(8,2,'Комплекты сцепления','&lt;br /&gt;\r\n','',''),
(12,2,'Корзины сцепления','&lt;br /&gt;\r\n','',''),
(15,2,'Болты сцепления','&lt;br /&gt;\r\n','',''),
(19,2,'Нажимные диски','&lt;br /&gt;\r\n','',''),
(23,2,'Тросы сцепления','&lt;br /&gt;\r\n','',''),
(11,2,'Амортизаторы','&lt;br /&gt;\r\n','',''),
(5,2,'Амортизаторы масляные','&lt;br /&gt;\r\n','',''),
(6,2,'Амортизаторы газовые','&lt;br /&gt;\r\n','',''),
(14,2,'Амортизатор подвески','&lt;br /&gt;\r\n','',''),
(16,2,'Буферы амортизатора','&lt;br /&gt;\r\n','',''),
(17,2,'Защитные комплекты','&lt;br /&gt;\r\n','',''),
(18,2,'Монтажные комплекты','&lt;br /&gt;\r\n','',''),
(20,2,'Опоры амортизаторов','&lt;br /&gt;\r\n','',''),
(21,2,'Пыльники амортизаторов','&lt;br /&gt;\r\n','',''),
(22,2,'Подшипники опоры','&lt;br /&gt;\r\n','',''),
(27,2,'SACHS','&lt;br /&gt;\r\n','',''),
(25,2,'BOGE','&lt;br /&gt;\r\n','',''),
(3,2,'SACHS','','',''),
(4,2,'BOGE','','','')	;
#	TC`oc_category_filter`utf8_general_ci	;
CREATE TABLE `oc_category_filter` (
  `category_id` int(11) NOT NULL,
  `filter_id` int(11) NOT NULL,
  PRIMARY KEY (`category_id`,`filter_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_category_path`utf8_general_ci	;
CREATE TABLE `oc_category_path` (
  `category_id` int(11) NOT NULL,
  `path_id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`category_id`,`path_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TD`oc_category_path`utf8_general_ci	;
INSERT INTO `oc_category_path` VALUES 
(13,13,0),
(25,25,0),
(26,25,0),
(26,26,1),
(27,27,0),
(10,27,0),
(10,10,1),
(7,27,0),
(7,10,1),
(7,7,2),
(8,27,0),
(8,10,1),
(8,8,2),
(12,27,0),
(12,10,1),
(12,12,2),
(15,27,0),
(15,10,1),
(15,15,2),
(19,27,0),
(19,10,1),
(19,19,2),
(23,27,0),
(23,10,1),
(23,23,2),
(11,27,0),
(11,11,1),
(5,27,0),
(5,11,1),
(5,5,2),
(6,27,0),
(6,11,1),
(6,6,2),
(14,27,0),
(14,11,1),
(14,14,2),
(16,27,0),
(16,11,1),
(16,16,2),
(17,27,0),
(17,11,1),
(17,17,2),
(18,27,0),
(18,11,1),
(18,18,2),
(20,27,0),
(20,11,1),
(20,20,2),
(21,27,0),
(21,11,1),
(21,21,2),
(22,27,0),
(22,11,1),
(22,22,2),
(3,3,0),
(4,4,0)	;
#	TC`oc_category_to_layout`utf8_bin	;
CREATE TABLE `oc_category_to_layout` (
  `category_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL,
  PRIMARY KEY (`category_id`,`store_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_category_to_store`utf8_bin	;
CREATE TABLE `oc_category_to_store` (
  `category_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  PRIMARY KEY (`category_id`,`store_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=9	;
#	TD`oc_category_to_store`utf8_bin	;
INSERT INTO `oc_category_to_store` VALUES 
(3,0),
(4,0),
(5,0),
(6,0),
(7,0),
(8,0),
(10,0),
(11,0),
(12,0),
(13,0),
(14,0),
(15,0),
(16,0),
(17,0),
(18,0),
(19,0),
(20,0),
(21,0),
(22,0),
(23,0),
(25,0),
(26,0),
(27,0)	;
#	TC`oc_country`utf8_bin	;
CREATE TABLE `oc_country` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `iso_code_2` varchar(2) COLLATE utf8_bin NOT NULL DEFAULT '',
  `iso_code_3` varchar(3) COLLATE utf8_bin NOT NULL DEFAULT '',
  `address_format` text COLLATE utf8_bin NOT NULL,
  `postcode_required` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`country_id`)
) ENGINE=MyISAM AUTO_INCREMENT=221 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=32	;
#	TD`oc_country`utf8_bin	;
INSERT INTO `oc_country` VALUES 
(220,'Украина','UA','UKR','',0,1)	;
#	TC`oc_coupon`utf8_general_ci	;
CREATE TABLE `oc_coupon` (
  `coupon_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `code` varchar(10) NOT NULL,
  `type` char(1) NOT NULL,
  `discount` decimal(15,4) NOT NULL,
  `logged` tinyint(1) NOT NULL,
  `shipping` tinyint(1) NOT NULL,
  `total` decimal(15,4) NOT NULL,
  `date_start` date NOT NULL DEFAULT '0000-00-00',
  `date_end` date NOT NULL DEFAULT '0000-00-00',
  `uses_total` int(11) NOT NULL,
  `uses_customer` varchar(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`coupon_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8	;
#	TD`oc_coupon`utf8_general_ci	;
INSERT INTO `oc_coupon` VALUES 
(4,'-10% Discount','2222','P',10.0000,0,0,0.0000,'2011-01-01','2012-01-01',10,'10',1,'2009-01-27 13:55:03'),
(5,'Free Shipping','3333','P',0.0000,0,1,100.0000,'2009-03-01','2009-08-31',10,'10',1,'2009-03-14 21:13:53'),
(6,'-10.00 Discount','1111','F',10.0000,0,0,10.0000,'1970-11-01','2020-11-01',100000,'10000',1,'2009-03-14 21:15:18')	;
#	TC`oc_coupon_category`utf8_general_ci	;
CREATE TABLE `oc_coupon_category` (
  `coupon_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`coupon_id`,`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_coupon_history`utf8_general_ci	;
CREATE TABLE `oc_coupon_history` (
  `coupon_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`coupon_history_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_coupon_product`utf8_general_ci	;
CREATE TABLE `oc_coupon_product` (
  `coupon_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`coupon_product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_currency`utf8_bin	;
CREATE TABLE `oc_currency` (
  `currency_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `code` varchar(3) COLLATE utf8_bin NOT NULL DEFAULT '',
  `symbol_left` varchar(12) COLLATE utf8_bin NOT NULL,
  `symbol_right` varchar(12) COLLATE utf8_bin NOT NULL,
  `decimal_place` char(1) COLLATE utf8_bin NOT NULL,
  `value` float(15,8) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`currency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=52	;
#	TD`oc_currency`utf8_bin	;
INSERT INTO `oc_currency` VALUES 
(4,'Гривны','UAH','',' грн','',1.00000000,1,'2012-10-03 07:25:56'),
(5,'Доллар','USD','','$','2',9.00000000,1,'2013-09-12 17:14:19')	;
#	TC`oc_custom_field`utf8_general_ci	;
CREATE TABLE `oc_custom_field` (
  `custom_field_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(32) NOT NULL,
  `value` text NOT NULL,
  `required` tinyint(1) NOT NULL,
  `location` varchar(32) NOT NULL,
  `position` int(3) NOT NULL,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`custom_field_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_custom_field_description`utf8_general_ci	;
CREATE TABLE `oc_custom_field_description` (
  `custom_field_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`custom_field_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_custom_field_to_customer_group`utf8_general_ci	;
CREATE TABLE `oc_custom_field_to_customer_group` (
  `custom_field_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  PRIMARY KEY (`custom_field_id`,`customer_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_custom_field_value`utf8_general_ci	;
CREATE TABLE `oc_custom_field_value` (
  `custom_field_value_id` int(11) NOT NULL AUTO_INCREMENT,
  `custom_field_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`custom_field_value_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_custom_field_value_description`utf8_general_ci	;
CREATE TABLE `oc_custom_field_value_description` (
  `custom_field_value_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`custom_field_value_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_customer`utf8_bin	;
CREATE TABLE `oc_customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `firstname` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `lastname` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `email` varchar(96) COLLATE utf8_bin NOT NULL DEFAULT '',
  `telephone` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `fax` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `password` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  `salt` varchar(9) COLLATE utf8_bin NOT NULL DEFAULT '',
  `cart` text COLLATE utf8_bin,
  `wishlist` text COLLATE utf8_bin,
  `newsletter` tinyint(1) NOT NULL DEFAULT '0',
  `address_id` int(11) NOT NULL DEFAULT '0',
  `customer_group_id` int(11) NOT NULL,
  `ip` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL,
  `approved` tinyint(1) NOT NULL,
  `token` varchar(255) COLLATE utf8_bin NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TD`oc_customer`utf8_bin	;
INSERT INTO `oc_customer` VALUES 
(2,0,'Александр Алексеевич','Борщенко','info@tuninga.com.ua','0980220286','','951b7ca03679ba40261c49394542c8d63682354e','e12e0456f','a:1:{s:6:\"2378::\";i:1;}','',1,2,1,'127.0.0.2',1,1,'','2012-11-12 12:20:12'),
(3,0,'Александр','РР','almasev@rambler.ru','0990022757','','1f5bae49c473315ff59ec1f10d95ffca39094b76','02e8bf726','a:0:{}','',0,3,1,'78.30.194.50',1,1,'','2012-11-14 15:31:47'),
(4,0,'Виталий Олегович','Колинко','vitalik-kolinko@mail.ru','0979039837','','ad0fe85ca640d2abc540ace5744639acc6f94df7','b36935a36','a:0:{}','',0,4,1,'178.219.92.89',1,1,'','2012-11-26 15:38:22'),
(5,0,'Михаил','Гломозда','marco_pol@live.ru','099 527 88 44','','74d7e6777dd790feca1edccf6a1a93554bf8a512','d663db5c4','a:0:{}','',1,5,1,'46.162.40.42',1,1,'','2012-12-08 20:15:43'),
(6,0,'ірпівріоооіач','ревеіррррррр','a@ukr.net','0652232525','','5549bb920c79e890457c85b8854d545b141efe2d','0fc3830db','a:0:{}','',0,6,1,'212.66.40.18',1,1,'','2013-01-19 16:49:38'),
(7,0,'Артур Александрович','Мороз','lispitstop@gmail.com','0506229187','','5484332968457b0de2137123addfb64fcdb9e0e0','5a94658c8','a:0:{}','',1,7,1,'46.200.72.60',1,1,'','2013-02-12 12:10:09'),
(8,0,'Николай','Бабюк','babiuk-nik@mail.ru','0675836194','','aef5f2bcd830bacbfaf7ddf4367fae0a5ef589e9','dcbb34a81','a:2:{s:6:\"2280::\";i:1;s:3:\"4::\";i:1;}','',0,8,1,'127.0.0.2',1,1,'','2013-03-16 21:20:10'),
(9,0,'Сергей Леонидович','Недавний','serezha72@bk.ru','0677689848','0523622224','bcdf935e472c57723a2ded75603f6ac97ae53462','8ed84bcea','a:0:{}','',1,9,1,'212.66.40.18',1,1,'','2013-03-27 22:38:06'),
(13,0,'Дмитрий','Зубенко','dimaster@i.ua','0675050403','','f3fabc0cfa7f1f99b7cfb48676469acd479297cd','88a8aa179','a:0:{}','',1,15,1,'37.57.204.179',1,1,'','2013-06-07 10:40:55'),
(10,0,'Аннаби','Осама','588640@mail.ru','0505512614','','3c36f75220a576c5deef201b0b2fcee9d0165a4f','fcf7a740c','a:0:{}','',0,10,1,'95.134.91.31',1,1,'','2013-04-03 13:07:56'),
(11,0,'Игорь','Кенич','ikenich@mail.ru','0509396430','','d9b42a3f0b9d964bd090fcb7e05620a2f58b99e5','c1e33316a','a:0:{}','',0,11,1,'37.53.219.16',1,1,'','2013-04-29 12:29:52'),
(12,0,'Сергей Анатольевич','Пиган','pigansergey@gmail.com','0663382949','','d5319891e8b7d456f61f2133ed79d3f83e0d5ab3','cba3d5819','a:0:{}','',0,12,1,'93.79.237.148',1,1,'','2013-05-07 08:12:47'),
(14,0,'денис михайлович','лазаренко','gw-e@yandex.ru','0984503516','','76f5623dfffe837f691fe4f5856ddc1223106203','77227d1bf','a:0:{}','',0,16,1,'176.116.76.155',1,1,'','2013-06-13 08:07:19'),
(15,0,'Микола Олегович','Любчак','newkakaxa@gmail.com','+380634038919','','246f0a58a2079af026002108beafea7dcf694337','419ed698a','a:0:{}','',0,17,1,'94.231.68.195',1,1,'','2013-06-22 21:53:52'),
(16,0,'Александр','Езерский','o.yezerskiy@gmail.com','0503716027','','09c94704da07286c3f3eb726e253c1023875ffd6','dc01e1e94','a:2:{i:3047;i:1;i:1655;i:1;}','',1,18,1,'193.238.96.13',1,1,'','2013-06-23 18:17:35'),
(17,0,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','2e45181ac737f484ffae91802a40ebb653903298','b80ed408f','a:1:{s:6:\"2376::\";i:1;}','',0,19,1,'127.0.0.2',1,1,'','2013-06-25 16:33:48'),
(18,0,'Олег Валериевич','Лановенко','olegshop@mail.ru','0958200086','','df5c413c9b5e80a7a78bd23d44272d1222d8f307','9958c923b','a:1:{i:3385;i:1;}','',1,20,1,'91.239.81.197',1,1,'','2013-07-11 10:20:23'),
(19,0,'Святослав Олегович','Пальчиков','pso_my@mail.ru','+380953869521','','85e75f410f4078cd40b5b4ec428454d906a64bd7','3c95d6ce8','a:0:{}','',0,21,1,'212.92.237.197',1,1,'','2013-08-03 02:15:28'),
(20,0,'Сергей','Захаренко','serviza@mail.ru','0939370057','','0e19006ad6b4f869d5eaf840974935c3a2577e57','a12c4f6a6','a:0:{}','',1,22,1,'178.158.206.131',1,1,'','2013-08-03 10:52:05'),
(21,0,'Дмитрий','Демиденко','dj_demick@mail.ru','0501825837','','9c438b96874edd9cc7fe9acb59fbb95d9dd02062','c9e6a6fd0','a:0:{}','',0,23,1,'93.127.2.96',1,1,'','2013-08-09 11:00:09'),
(22,0,'игор','дрожак','drogak.igor@rambler.ru','0976231988','','9b104bab75cfb36d4a5006707c1ef791ab827103','5cf0ff1da','a:0:{}','',0,24,1,'82.207.98.109',1,1,'','2013-08-12 07:31:58'),
(23,0,'Сергей Михайлович','Секеда','office@gammapromservice.com.ua','0675783970','','04f837216d96eb51bf15da5d6cec250ffdf51265','9f1dfe7d0','a:1:{i:2798;i:1;}','',0,25,1,'178.150.141.226',1,1,'','2013-08-13 11:39:47'),
(24,0,'Евгений Владимирович','Рева','zhenya.reva.88@mail.ru','0967984367','','ec6fa4fe48e8610f198bfc59e42bd5529b362f52','b43ce2778','a:0:{}','',1,26,1,'195.225.145.16',1,1,'','2013-08-15 11:36:20'),
(25,0,'Евгений Владимирович','Соловьёв','slvevg@mail.ru','0668148379','','051f55ad61d36768c3f628a6a9027bcf9c064486','47c305cfc','a:0:{}','',0,27,1,'46.175.136.15',1,1,'','2013-08-25 01:02:37'),
(26,0,'алексеенко','максим','avtomaximus@rambler.ru','0678977377','','7b54ef947bb97095ba57c859da6f23a51c5b1958','1bbf8138e','a:0:{}','',0,28,1,'81.30.173.154',1,1,'','2013-08-27 12:57:34')	;
#	TC`oc_customer_ban_ip`utf8_general_ci	;
CREATE TABLE `oc_customer_ban_ip` (
  `customer_ban_ip_id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(40) NOT NULL,
  PRIMARY KEY (`customer_ban_ip_id`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_customer_field`utf8_general_ci	;
CREATE TABLE `oc_customer_field` (
  `customer_id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `custom_field_value_id` int(11) NOT NULL,
  `name` int(128) NOT NULL,
  `value` text NOT NULL,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`customer_id`,`custom_field_id`,`custom_field_value_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_customer_group`utf8_bin	;
CREATE TABLE `oc_customer_group` (
  `customer_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `approval` int(1) NOT NULL,
  `company_id_display` int(1) NOT NULL,
  `company_id_required` int(1) NOT NULL,
  `tax_id_display` int(1) NOT NULL,
  `tax_id_required` int(1) NOT NULL,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`customer_group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=29	;
#	TD`oc_customer_group`utf8_bin	;
INSERT INTO `oc_customer_group` VALUES 
(1,0,0,0,0,0,1)	;
#	TC`oc_customer_group_description`utf8_bin	;
CREATE TABLE `oc_customer_group_description` (
  `customer_group_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(32) COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`customer_group_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=36	;
#	TD`oc_customer_group_description`utf8_bin	;
INSERT INTO `oc_customer_group_description` VALUES 
(1,2,'Стандартная','')	;
#	TC`oc_customer_history`utf8_general_ci	;
CREATE TABLE `oc_customer_history` (
  `customer_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`customer_history_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_customer_ip`utf8_bin	;
CREATE TABLE `oc_customer_ip` (
  `customer_ip_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`customer_ip_id`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TD`oc_customer_ip`utf8_bin	;
INSERT INTO `oc_customer_ip` VALUES 
(2,2,'95.133.178.186','2012-11-12 12:20:12'),
(3,3,'78.30.194.50','2012-11-14 15:31:48'),
(4,4,'178.219.92.89','2012-11-26 15:38:22'),
(5,5,'46.162.40.42','2012-12-08 20:15:43'),
(6,6,'94.231.178.30','2013-01-19 16:49:38'),
(7,7,'94.178.54.175','2013-02-12 12:10:09'),
(8,7,'46.200.72.60','2013-02-12 14:25:03'),
(9,8,'46.247.129.15','2013-03-16 21:20:11'),
(10,9,'92.113.120.151','2013-03-27 22:38:07'),
(11,8,'78.111.187.126','2013-03-31 22:05:12'),
(12,10,'95.134.91.31','2013-04-03 13:07:56'),
(13,11,'37.53.219.16','2013-04-29 12:29:52'),
(14,12,'93.79.237.148','2013-05-07 08:12:50'),
(15,8,'46.247.146.11','2013-05-09 14:22:03'),
(16,8,'46.247.159.210','2013-05-12 21:26:47'),
(17,8,'46.247.144.143','2013-05-13 08:39:12'),
(18,8,'46.247.130.109','2013-05-14 13:49:21'),
(19,8,'46.247.151.253','2013-05-14 23:41:25'),
(20,8,'46.247.130.193','2013-05-15 08:19:08'),
(21,8,'46.247.154.191','2013-05-15 10:38:48'),
(22,8,'46.247.134.171','2013-05-15 12:14:45'),
(23,8,'46.247.139.77','2013-05-15 18:39:39'),
(24,8,'46.247.154.180','2013-05-15 21:41:31'),
(25,8,'46.247.131.72','2013-05-16 09:34:38'),
(26,8,'46.247.132.54','2013-05-16 14:24:30'),
(27,8,'46.247.146.126','2013-05-16 23:13:40'),
(28,8,'46.247.154.57','2013-05-17 22:12:24'),
(29,8,'46.247.135.230','2013-05-18 12:13:35'),
(30,8,'46.247.154.12','2013-06-03 11:12:16'),
(31,13,'37.57.204.179','2013-06-07 10:40:55'),
(32,14,'176.116.66.116','2013-06-13 08:07:19'),
(33,14,'176.116.73.20','2013-06-14 08:22:32'),
(34,14,'176.116.66.104','2013-06-15 21:31:50'),
(35,14,'176.116.65.111','2013-06-18 09:46:12'),
(36,14,'176.116.76.155','2013-06-21 17:36:45'),
(37,15,'94.231.68.195','2013-06-22 21:53:52'),
(38,16,'37.55.69.127','2013-06-23 18:17:35'),
(39,16,'193.238.96.13','2013-06-23 22:22:49'),
(40,8,'46.247.145.127','2013-06-25 09:35:56'),
(41,17,'193.238.98.177','2013-06-25 16:33:48'),
(42,17,'193.238.96.13','2013-06-25 22:58:43'),
(43,8,'46.247.132.147','2013-06-26 21:52:20'),
(44,8,'46.247.150.182','2013-07-01 17:09:56'),
(45,8,'46.247.143.68','2013-07-02 20:49:05'),
(46,18,'91.239.81.197','2013-07-11 10:20:23'),
(47,19,'212.92.237.197','2013-08-03 02:15:28'),
(48,20,'178.158.206.131','2013-08-03 10:52:06'),
(49,21,'93.127.2.96','2013-08-09 11:00:09'),
(50,22,'82.207.98.109','2013-08-12 07:31:59'),
(51,23,'178.150.141.226','2013-08-13 11:39:47'),
(52,24,'195.225.145.16','2013-08-15 11:36:20'),
(53,25,'46.175.136.15','2013-08-25 01:02:37'),
(54,26,'81.30.173.154','2013-08-27 12:57:34'),
(55,6,'212.66.40.18','2013-09-09 10:10:44'),
(56,9,'212.66.40.18','2013-09-10 12:39:29'),
(57,2,'127.0.0.2','2013-09-10 14:11:04'),
(58,17,'127.0.0.2','2013-09-11 09:51:17'),
(59,8,'127.0.0.2','2013-09-12 09:45:13')	;
#	TC`oc_customer_ip_blacklist`utf8_bin	;
CREATE TABLE `oc_customer_ip_blacklist` (
  `customer_ip_blacklist_id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(40) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`customer_ip_blacklist_id`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_customer_online`utf8_bin	;
CREATE TABLE `oc_customer_online` (
  `ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `customer_id` int(11) NOT NULL,
  `url` text COLLATE utf8_bin NOT NULL,
  `referer` text COLLATE utf8_bin NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_customer_reward`utf8_bin	;
CREATE TABLE `oc_customer_reward` (
  `customer_reward_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `order_id` int(11) NOT NULL DEFAULT '0',
  `description` text COLLATE utf8_bin NOT NULL,
  `points` int(8) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`customer_reward_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_customer_transaction`utf8_bin	;
CREATE TABLE `oc_customer_transaction` (
  `customer_transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`customer_transaction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_download`utf8_general_ci	;
CREATE TABLE `oc_download` (
  `download_id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(128) NOT NULL,
  `mask` varchar(128) NOT NULL,
  `remaining` int(11) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`download_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_download_description`utf8_general_ci	;
CREATE TABLE `oc_download_description` (
  `download_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`download_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_extension`utf8_bin	;
CREATE TABLE `oc_extension` (
  `extension_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(32) COLLATE utf8_bin NOT NULL,
  `code` varchar(32) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`extension_id`)
) ENGINE=MyISAM AUTO_INCREMENT=455 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=24	;
#	TD`oc_extension`utf8_bin	;
INSERT INTO `oc_extension` VALUES 
(445,'module','latest'),
(22,'total','shipping'),
(57,'total','sub_total'),
(58,'total','tax'),
(59,'total','total'),
(437,'shipping','pickup'),
(413,'module','category'),
(408,'module','account'),
(438,'shipping','delivery'),
(427,'module','featured'),
(450,'payment','prepay'),
(428,'module','contact'),
(439,'feed','google_sitemap'),
(454,'module','google_talk'),
(453,'module','price_import'),
(446,'payment','nochex'),
(447,'payment','cashless'),
(452,'payment','cod')	;
#	TC`oc_filter`utf8_general_ci	;
CREATE TABLE `oc_filter` (
  `filter_id` int(11) NOT NULL AUTO_INCREMENT,
  `filter_group_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`filter_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_filter_description`utf8_general_ci	;
CREATE TABLE `oc_filter_description` (
  `filter_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `filter_group_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`filter_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_filter_group`utf8_general_ci	;
CREATE TABLE `oc_filter_group` (
  `filter_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`filter_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_filter_group_description`utf8_general_ci	;
CREATE TABLE `oc_filter_group_description` (
  `filter_group_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`filter_group_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_geo_zone`utf8_bin	;
CREATE TABLE `oc_geo_zone` (
  `geo_zone_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `description` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`geo_zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_information`utf8_bin	;
CREATE TABLE `oc_information` (
  `information_id` int(11) NOT NULL AUTO_INCREMENT,
  `bottom` int(1) NOT NULL DEFAULT '0',
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`information_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=14	;
#	TD`oc_information`utf8_bin	;
INSERT INTO `oc_information` VALUES 
(7,1,3,1),
(8,0,5,1),
(9,1,4,1)	;
#	TC`oc_information_description`utf8_bin	;
CREATE TABLE `oc_information_description` (
  `information_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `title` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `description` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`information_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=3590	;
#	TD`oc_information_description`utf8_bin	;
INSERT INTO `oc_information_description` VALUES 
(8,2,'Как сделать заказ?','&lt;p&gt;\r\n	Оформление заказа через форму на сайте:&lt;/p&gt;\r\n&lt;ol&gt;\r\n	&lt;li&gt;\r\n		Выбираете необходимый товар&lt;/li&gt;\r\n	&lt;li&gt;\r\n		Нажимаете на кнопку&amp;nbsp;&lt;input class=&quot;button&quot; id=&quot;button-cart&quot; type=&quot;button&quot; value=&quot;Купить&quot; /&gt;&lt;/li&gt;\r\n	&lt;li&gt;\r\n		В корзине покупок переходите по ссылке &lt;span style=&quot;color:#0000cd;&quot;&gt;&lt;u&gt;Оформление заказа&lt;/u&gt;&lt;/span&gt;&lt;/li&gt;\r\n	&lt;li&gt;\r\n		На следующем этапе можно выбрать оформление заказа через &lt;strong&gt;регистрацию&lt;/strong&gt; (позволяет однажды авторизоваться на сайте и совершать покупки не повторяя ввод контактной информации + получать свежую информацию) и &lt;strong&gt;без регистрации&lt;/strong&gt;.&lt;/li&gt;\r\n&lt;/ol&gt;\r\n&lt;p&gt;\r\n	После совершения заказа наши менеджеры с Вами могут связаться по телефону, поэтому указывайте &lt;u&gt;правильный номер телефона&lt;/u&gt;!&lt;/p&gt;\r\n&lt;p&gt;\r\n	Также &lt;u&gt;возможно совершить заказ по телефону&lt;/u&gt; - для этого наберите любой номер телефона указанный в заголовке сайта. Прием звонков: &lt;strong&gt;Пн&lt;/strong&gt; - &lt;strong&gt;Пт&lt;/strong&gt; с 9&lt;sup&gt;00&lt;/sup&gt; до 18&lt;sup&gt;00&lt;/sup&gt;&lt;/p&gt;\r\n'),
(9,2,'Подбор по авто','&lt;script type=&quot;text/javascript&quot;&gt;\r\nfunction setHeight() {\r\n    parent.document.getElementById(\'podbor\').height = document[\'body\'].offsetHeight;\r\n}\r\n&lt;/script&gt;\r\n&lt;p&gt;\r\n	&lt;iframe frameborder=&quot;0&quot; height=&quot;auto&quot; hspace=&quot;0&quot; id=&quot;podbor&quot; marginheight=&quot;0&quot; marginwidth=&quot;0&quot; onload=&quot;setHeight()&quot; scrolling=&quot;no&quot; src=&quot;http://sachs.com.ua/selection/index.php&quot; vspace=&quot;0&quot; width=&quot;550&quot;&gt;&lt;/iframe&gt;&lt;/p&gt;\r\n'),
(7,2,'Оплата и доставка','&lt;h2&gt;\r\n	Доставка&lt;/h2&gt;\r\n&lt;p&gt;\r\n	Отправка товара по Украине осуществляется следующими фирмами-перевозчиками: &lt;strong&gt;&lt;a href=&quot;http://novaposhta.ua/&quot; onclick=&quot;return !window.open(this.href)&quot; rel=&quot;nofollow&quot; title=&quot;Новая почта&quot;&gt;Новая почта&lt;/a&gt;&lt;/strong&gt;, &lt;strong&gt;&lt;a href=&quot;http://www.delivery-auto.com/ru/&quot; onclick=&quot;return !window.open(this.href)&quot; rel=&quot;nofollow&quot; title=&quot;Деливери&quot;&gt;Деливери&lt;/a&gt;&lt;/strong&gt;, &lt;strong&gt;&lt;a href=&quot;http://www.intime.ua/&quot; onclick=&quot;return !window.open(this.href)&quot; rel=&quot;nofollow&quot; title=&quot;Интайм&quot;&gt;Ин-тайм&lt;/a&gt;&lt;/strong&gt;, &lt;strong&gt;&lt;a href=&quot;http://www.gunsel.com.ua/&quot; onclick=&quot;return !window.open(this.href)&quot; rel=&quot;nofollow&quot; title=&quot;Гюнсел&quot;&gt;Гюнсел&lt;/a&gt;&lt;/strong&gt;, &lt;strong&gt;&lt;a href=&quot;http://www.autolux.ua/&quot; target=&quot;_blank&quot; title=&quot;Автолюкс&quot;&gt;Автолюкс&lt;/a&gt;&lt;/strong&gt;. Если в вашем городе нет представительств этих компаний, то Вам следует обратиться к менеджеру магазина для согласования способа отправки. Оплату услуг транспортной компании производит клиент при получении товара. По умолчанию, грузы, отправляемые клиентам в регионы транспортными компаниями, не страхуются. При оформлении заказа клиент должен самостоятельно оценить необходимость страхования отправляемого ему груза и указать это в поле &quot;Комментарии к заказу&quot;. Также, рекомендуем в поле&amp;nbsp; &quot;Комментарии к заказу&quot; указать номер склада перевозчика в пункте назначения.&lt;/p&gt;\r\n&lt;p&gt;\r\n	Интернет-магазин не несет ответственности за повреждение незастрахованного груза в ходе перевозки транспортной компанией. В этом случае все претензии по поврежденному грузу клиент вправе выставить перевозчику.&lt;/p&gt;\r\n&lt;p&gt;\r\n	Информацию об отправленных Вам товарах можно получить у &amp;nbsp;менеджера магазина.&lt;/p&gt;\r\n&lt;h2&gt;\r\n	Оплата&lt;/h2&gt;\r\n&lt;p&gt;\r\n	Оплата заказов осуществляется в гривнах. Цены, приведенные на сайте указаны на условиях самовывоза со склада интернет-магазина.&lt;/p&gt;\r\n&lt;p&gt;\r\n	Реквизиты для частных лиц, а также юр. лиц неплательщиков НДС:&lt;/p&gt;\r\n&lt;p style=&quot;border: 1px dashed #808080; padding: 7px; background: #fff; width: 80%; font-family: courier;&quot;&gt;\r\n	ФЛП Кравцов Олег Геннадьевич ЕГРПОУ: 2504700472&lt;br /&gt;\r\n	частный предприниматель на едином налоге, неплательщик НДС&lt;br /&gt;\r\n	р/с 26001962487710 в ПАТ ПУБМ МФО 334851&lt;/p&gt;\r\n&lt;p&gt;\r\n	Также Вы можете перевести нам средства на кредитные карты (карточные счета):&lt;/p&gt;\r\n&lt;p style=&quot;border: 1px dashed #808080; padding: 7px; background: #fff; width: 80%; font-family: courier;&quot;&gt;\r\n	ПриватБанк ГРН № карты&amp;nbsp;5168 7420 6108 4012 (комиссия +1%)&lt;br /&gt;\r\n	ПУМБ ГРН № карты 4314 3723 0025 0392&lt;br /&gt;\r\n	Универсал Банк ГРН № счета 2620 4000 4429 31&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;strong&gt;&lt;span style=&quot;color: #800000;&quot;&gt;Внимание!&lt;/span&gt; Если Вы оплачиваете через терминал, то обязательно сообщите дату, сумму и фамилию плательщика. Иначе нет гарантии, что заказ будет обработан.&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;\r\n	Реквизиты для юр. лиц плательщиков НДС:&amp;nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;border: 1px dashed #808080; padding: 7px; background: #fff; width: 80%; font-family: courier;&quot;&gt;\r\n	ООО &quot;КОМПАНИЯ ТЕСМА&quot;&lt;br /&gt;\r\n	ЕДРПОУ 34899101, тел.(062) 385-68-86&lt;br /&gt;\r\n	РСЧ 26002962484541 в ПАО &quot;ПУМБ&quot; МФО 334851&lt;br /&gt;\r\n	ИНН 348991005643, номер свидетельства 100021148&lt;br /&gt;\r\n	Является плательщиком налога на прибыль на общих основаниях&lt;br /&gt;\r\n	Адрес 83007, г.Донецк, ул.Буслаева, 10&lt;/p&gt;\r\n&lt;p&gt;\r\n	Юридическим лицам предоставляются все отчетные документы согласно действующего законодательства. Налоговые накладные высылаются в начале месяца, следующего за отчетным.&lt;/p&gt;\r\n')	;
#	TC`oc_information_to_layout`utf8_bin	;
CREATE TABLE `oc_information_to_layout` (
  `information_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL,
  PRIMARY KEY (`information_id`,`store_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_information_to_store`utf8_bin	;
CREATE TABLE `oc_information_to_store` (
  `information_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  PRIMARY KEY (`information_id`,`store_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=9	;
#	TD`oc_information_to_store`utf8_bin	;
INSERT INTO `oc_information_to_store` VALUES 
(7,0),
(8,0),
(9,0)	;
#	TC`oc_language`utf8_bin	;
CREATE TABLE `oc_language` (
  `language_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `code` varchar(5) COLLATE utf8_bin NOT NULL,
  `locale` varchar(255) COLLATE utf8_bin NOT NULL,
  `image` varchar(64) COLLATE utf8_bin NOT NULL,
  `directory` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `filename` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`language_id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=80	;
#	TD`oc_language`utf8_bin	;
INSERT INTO `oc_language` VALUES 
(2,'Russian','ru','ru_RU.UTF-8,ru_RU,ru-gb,russian','ru.png','russian','russian',1,1)	;
#	TC`oc_layout`utf8_bin	;
CREATE TABLE `oc_layout` (
  `layout_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`layout_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=20	;
#	TD`oc_layout`utf8_bin	;
INSERT INTO `oc_layout` VALUES 
(1,'Home'),
(2,'Product'),
(3,'Category'),
(4,'Default'),
(5,'Manufacturer'),
(6,'Account'),
(7,'Checkout'),
(8,'Contact'),
(9,'Sitemap'),
(10,'Affiliate'),
(11,'Information')	;
#	TC`oc_layout_route`utf8_bin	;
CREATE TABLE `oc_layout_route` (
  `layout_route_id` int(11) NOT NULL AUTO_INCREMENT,
  `layout_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `route` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`layout_route_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=28	;
#	TD`oc_layout_route`utf8_bin	;
INSERT INTO `oc_layout_route` VALUES 
(30,6,0,'account'),
(17,10,0,'affiliate/'),
(29,3,0,'product/category'),
(26,1,0,'common/home'),
(20,2,0,'product/product'),
(24,11,0,'information/information'),
(22,5,0,'product/manufacturer'),
(23,7,0,'checkout/'),
(31,8,0,'information/contact')	;
#	TC`oc_length_class`utf8_bin	;
CREATE TABLE `oc_length_class` (
  `length_class_id` int(11) NOT NULL AUTO_INCREMENT,
  `value` decimal(15,8) NOT NULL,
  PRIMARY KEY (`length_class_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=13	;
#	TD`oc_length_class`utf8_bin	;
INSERT INTO `oc_length_class` VALUES 
(1,1.00000000),
(2,10.00000000),
(3,0.39370000)	;
#	TC`oc_length_class_description`utf8_bin	;
CREATE TABLE `oc_length_class_description` (
  `length_class_id` int(11) NOT NULL AUTO_INCREMENT,
  `language_id` int(11) NOT NULL,
  `title` varchar(32) COLLATE utf8_bin NOT NULL,
  `unit` varchar(4) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`length_class_id`,`language_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=36	;
#	TD`oc_length_class_description`utf8_bin	;
INSERT INTO `oc_length_class_description` VALUES 
(1,2,'Сантиметры','см'),
(2,2,'Миллиметры','мм'),
(3,2,'Дюймы','in')	;
#	TC`oc_manufacturer`utf8_bin	;
CREATE TABLE `oc_manufacturer` (
  `manufacturer_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `image` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`manufacturer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=230 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=20	;
#	TD`oc_manufacturer`utf8_bin	;
INSERT INTO `oc_manufacturer` VALUES 
(20,'SACHS',\N,0),
(21,'BOGE',\N,0),
(229,'SACHS-S',\N,0),
(228,'GROUPNAME',\N,0)	;
#	TC`oc_manufacturer_to_store`utf8_bin	;
CREATE TABLE `oc_manufacturer_to_store` (
  `manufacturer_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  PRIMARY KEY (`manufacturer_id`,`store_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=9	;
#	TD`oc_manufacturer_to_store`utf8_bin	;
INSERT INTO `oc_manufacturer_to_store` VALUES 
(20,0),
(21,0),
(229,0)	;
#	TC`oc_option`utf8_bin	;
CREATE TABLE `oc_option` (
  `option_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(32) COLLATE utf8_bin NOT NULL,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=21	;
#	TD`oc_option`utf8_bin	;
INSERT INTO `oc_option` VALUES 
(1,'radio',2),
(2,'checkbox',3),
(4,'text',4),
(5,'select',1),
(6,'textarea',5),
(7,'file',6),
(8,'date',7),
(9,'time',8),
(10,'datetime',9),
(11,'select',1),
(12,'date',1)	;
#	TC`oc_option_description`utf8_bin	;
CREATE TABLE `oc_option_description` (
  `option_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`option_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=22	;
#	TD`oc_option_description`utf8_bin	;
INSERT INTO `oc_option_description` VALUES 
(1,2,'Radio'),
(2,2,'Checkbox'),
(4,2,'Text'),
(6,2,'Textarea'),
(8,2,'Date'),
(7,2,'File'),
(5,2,'Select'),
(9,2,'Time'),
(10,2,'Date &amp; Time'),
(12,2,'Delivery Date'),
(11,2,'Size')	;
#	TC`oc_option_value`utf8_bin	;
CREATE TABLE `oc_option_value` (
  `option_value_id` int(11) NOT NULL AUTO_INCREMENT,
  `option_id` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8_bin NOT NULL,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`option_value_id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=20	;
#	TD`oc_option_value`utf8_bin	;
INSERT INTO `oc_option_value` VALUES 
(43,1,'',3),
(32,1,'',1),
(45,2,'',4),
(44,2,'',3),
(42,5,'',4),
(41,5,'',3),
(39,5,'',1),
(40,5,'',2),
(31,1,'',2),
(23,2,'',1),
(24,2,'',2),
(46,11,'',1),
(47,11,'',2),
(48,11,'',3)	;
#	TC`oc_option_value_description`utf8_bin	;
CREATE TABLE `oc_option_value_description` (
  `option_value_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`option_value_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=24	;
#	TD`oc_option_value_description`utf8_bin	;
INSERT INTO `oc_option_value_description` VALUES 
(43,2,1,'Large'),
(32,2,1,'Small'),
(45,2,2,'Checkbox 4'),
(44,2,2,'Checkbox 3'),
(31,2,1,'Medium'),
(42,2,5,'Yellow'),
(41,2,5,'Green'),
(39,2,5,'Red'),
(40,2,5,'Blue'),
(23,2,2,'Checkbox 1'),
(24,2,2,'Checkbox 2'),
(48,2,11,'Large'),
(47,2,11,'Medium'),
(46,2,11,'Small')	;
#	TC`oc_order`utf8_bin	;
CREATE TABLE `oc_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` int(11) NOT NULL DEFAULT '0',
  `invoice_prefix` varchar(26) COLLATE utf8_bin NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `store_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `store_url` varchar(255) COLLATE utf8_bin NOT NULL,
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `customer_group_id` int(11) NOT NULL DEFAULT '0',
  `firstname` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `lastname` varchar(32) COLLATE utf8_bin NOT NULL,
  `email` varchar(96) COLLATE utf8_bin NOT NULL,
  `telephone` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `fax` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `payment_firstname` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `payment_lastname` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `payment_company` varchar(32) COLLATE utf8_bin NOT NULL,
  `payment_company_id` varchar(32) COLLATE utf8_bin NOT NULL,
  `payment_tax_id` varchar(32) COLLATE utf8_bin NOT NULL,
  `payment_address_1` varchar(128) COLLATE utf8_bin NOT NULL,
  `payment_address_2` varchar(128) COLLATE utf8_bin NOT NULL,
  `payment_city` varchar(128) COLLATE utf8_bin NOT NULL,
  `payment_postcode` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT '',
  `payment_country` varchar(128) COLLATE utf8_bin NOT NULL,
  `payment_country_id` int(11) NOT NULL,
  `payment_zone` varchar(128) COLLATE utf8_bin NOT NULL,
  `payment_zone_id` int(11) NOT NULL,
  `payment_address_format` text COLLATE utf8_bin NOT NULL,
  `payment_method` varchar(128) COLLATE utf8_bin NOT NULL DEFAULT '',
  `payment_code` varchar(128) COLLATE utf8_bin NOT NULL,
  `shipping_firstname` varchar(32) COLLATE utf8_bin NOT NULL,
  `shipping_lastname` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `shipping_company` varchar(32) COLLATE utf8_bin NOT NULL,
  `shipping_address_1` varchar(128) COLLATE utf8_bin NOT NULL,
  `shipping_address_2` varchar(128) COLLATE utf8_bin NOT NULL,
  `shipping_city` varchar(128) COLLATE utf8_bin NOT NULL,
  `shipping_postcode` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT '',
  `shipping_country` varchar(128) COLLATE utf8_bin NOT NULL,
  `shipping_country_id` int(11) NOT NULL,
  `shipping_zone` varchar(128) COLLATE utf8_bin NOT NULL,
  `shipping_zone_id` int(11) NOT NULL,
  `shipping_address_format` text COLLATE utf8_bin NOT NULL,
  `shipping_method` varchar(128) COLLATE utf8_bin NOT NULL DEFAULT '',
  `shipping_code` varchar(128) COLLATE utf8_bin NOT NULL,
  `comment` text COLLATE utf8_bin NOT NULL,
  `total` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `order_status_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_id` int(11) NOT NULL,
  `commission` decimal(15,4) NOT NULL,
  `language_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `currency_code` varchar(3) COLLATE utf8_bin NOT NULL,
  `currency_value` decimal(15,8) NOT NULL DEFAULT '1.00000000',
  `ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `forwarded_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `user_agent` varchar(255) COLLATE utf8_bin NOT NULL,
  `accept_language` varchar(255) COLLATE utf8_bin NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=77 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=565	;
#	TD`oc_order`utf8_bin	;
INSERT INTO `oc_order` VALUES 
(1,0,'INV-2012-00',0,'Your Store','http://opencart/',0,1,'asdf','asdf','asdf@asdf.ru','4654312','','asdf','asdf','','','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Наложенный платёж (+5%)','cod','asdf','asdf','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Фиксированная стоимость доставки','flat.flat','',127.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 12:27:54','2012-10-03 12:27:54'),
(2,0,'INV-2012-00',0,'Your Store','http://opencart/',0,1,'asdf','asdf','asdf@asdf.ru','4654312','','asdf','asdf','','','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Банковский перевод','bank_transfer','asdf','asdf','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Фиксированная стоимость доставки','flat.flat','',127.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 12:31:48','2012-10-03 12:31:48'),
(3,0,'INV-2012-00',0,'Your Store','http://opencart/',0,1,'asdf','asdf','asdf@asdf.ru','4654312','','asdf','asdf','','','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Наложенный платёж (+5%)','cod','asdf','asdf','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Фиксированная стоимость доставки','flat.flat','',127.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 12:41:31','2012-10-03 12:41:31'),
(4,0,'INV-2012-00',0,'Your Store','http://opencart/',0,1,'asdf','asdf','asdf@asdf.ru','4654312','','asdf','asdf','','','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Наложенный платёж (+5%)','cod','asdf','asdf','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Фиксированная стоимость доставки','flat.flat','',127.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 14:10:20','2012-10-03 14:10:20'),
(5,0,'INV-2012-00',0,'Your Store','http://opencart/',0,1,'asdf','asdf','asdf@asdf.ru','4654312','','asdf','asdf','','','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Наложенный платёж (+5%)','cod','asdf','asdf','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Фиксированная стоимость доставки','flat.flat','',127.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 14:16:28','2012-10-03 14:16:28'),
(6,0,'INV-2012-00',0,'Your Store','http://opencart/',0,1,'asdf','asdf','asdf@asdf.ru','4654312','','asdf','asdf','','','','asdf','','asdf','','Украина',220,'АР Крым',3483,'','Наложенный платёж (+5%)','cod','asdf','asdf','','asdf','','asdf','','Украина',220,'АР Крым',3483,'','Фиксированная стоимость доставки','flat.flat','',127.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 14:18:13','2012-10-03 14:18:13'),
(8,0,'INV-2012-00',0,'Your Store','http://opencart/',0,1,'фыва','asdf','asdf@asdf.ua','46987','','фыва','asdf','','','','asdf','','Донецк','','Украина',220,'Донецкая область',3485,'','Наложенный платёж (+5%)','cod','фыва','asdf','','asdf','','Донецк','','Украина',220,'Донецкая область',3485,'','Фиксированная стоимость доставки','flat.flat','',127.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 14:47:00','2012-10-03 14:47:00'),
(9,0,'INV-2012-00',0,'Your Store','http://opencart/',0,1,'фыва','asdf','asdf@asdf.ua','46987','','фыва','asdf','','','','asdf','','Донецк','','Украина',220,'Донецкая область',3485,'','Наложенный платёж (+5%)','cod','фыва','asdf','','asdf','','Донецк','','Украина',220,'Донецкая область',3485,'','Фиксированная стоимость доставки','flat.flat','',127.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 14:48:41','2012-10-03 14:48:41'),
(10,0,'INV-2012-00',0,'Your Store','http://opencart/',1,1,'test','test','test@test.ua','464898','','test','test','','','','test','','test','','Украина',220,'Донецкая область',3485,'','Наложенный платёж (+5%)','cod','test','test','','test','','test','','Украина',220,'Донецкая область',3485,'','Фиксированная стоимость доставки','flat.flat','',127.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 14:53:36','2012-10-03 14:53:36'),
(11,0,'INV-2012-00',0,'Your Store','http://opencart/',1,1,'test','test','test@test.ua','464898','','test','test','','','','test','','test','','Украина',220,'Донецкая область',3485,'','Наложенный платёж (+5%)','cod','test','test','','test','','test','','Украина',220,'Донецкая область',3485,'','Фиксированная стоимость доставки','flat.flat','',127.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 14:54:56','2012-10-03 14:54:56'),
(12,0,'INV-2012-00',0,'Your Store','http://opencart/',0,1,'qwer','qwer','qqwer@er.ru','123423','','qwer','qwer','','','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Наложенный платёж (+5%)','cod','qwer','qwer','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Фиксированная стоимость доставки','flat.flat','',127.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 14:58:57','2012-10-03 14:58:57'),
(13,0,'INV-2012-00',0,'Your Store','http://opencart/',0,1,'qwer','qwer','qqwer@er.ru','123423','','qwer','qwer','','','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Банковский перевод','bank_transfer','qwer','qwer','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',122.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 15:09:50','2012-10-03 15:09:50'),
(14,0,'INV-2012-00',0,'Your Store','http://opencart/',0,1,'qwer','qwer','qqwer@er.ru','123423','','qwer','qwer','','','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Банковский перевод','bank_transfer','qwer','qwer','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',122.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 15:09:55','2012-10-03 15:09:55'),
(15,0,'INV-2012-00',0,'Your Store','http://opencart/',0,1,'qwer','qwer','qqwer@er.ru','123423','','qwer','qwer','','','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Банковский перевод','bank_transfer','qwer','qwer','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',122.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 15:11:30','2012-10-03 15:11:30'),
(16,0,'INV-2012-00',0,'Your Store','http://opencart/',0,1,'qwer','qwer','qqwer@er.ru','123423','','qwer','qwer','','','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Наложенный платёж (+5%)','cod','qwer','qwer','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',128.1000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 15:48:49','2012-10-03 15:48:49'),
(17,0,'INV-2012-00',0,'Your Store','http://opencart/',0,1,'qwer','qwer','qqwer@er.ru','123423','','qwer','qwer','','','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Банковский перевод','bank_transfer','qwer','qwer','','asdf','','asdf','','Украина',220,'Донецкая область',3485,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',128.1000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-10-03 15:49:17','2012-10-03 15:49:17'),
(19,1,'INV-2012-00',0,'sachs','http://sachs.com.ua/',2,1,'Александр Алексеевич','Борщенко','info@tuninga.com.ua','0980220286','','Александр Алексеевич','Борщенко','Автосклад-Эксперт','','','пр-т Краснозвездный 99','','Киев','','Украина',220,'Киевская область',3490,'','Банковский перевод','bank_transfer','Александр Алексеевич','Борщенко','Автосклад-Эксперт','пр-т Краснозвездный 99','','Киев','','Украина',220,'Киевская область',3490,'','Самовывоз из магазина','pickup.pickup','',2736.0000,18,0,0.0000,2,4,'UAH',1.00000000,'95.133.178.186','95.133.178.186','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.10','ru-RU,ru;q=0.9,en;q=0.8','2012-11-12 12:21:15','2012-11-12 12:24:33'),
(20,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',3,1,'Александр','РР','almasev@rambler.ru','0990022757','','Александр','РР','','','','пр.Героев Сталинграда','','Севастополь','99059','Украина',220,'АР Крым',3483,'','Наложенный платёж (+5%)','cod','Александр','РР','','пр.Героев Сталинграда','','Севастополь','99059','Украина',220,'АР Крым',3483,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',265.0000,1,0,0.0000,2,4,'UAH',1.00000000,'78.30.194.50','78.30.194.50','Opera/9.80 (Windows NT 6.1; WOW64; Edition Indonesian Local) Presto/2.12.388 Version/12.10','ru,ru-RU;q=0.9,en;q=0.8','2012-11-14 15:41:55','2012-11-14 15:42:02'),
(21,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',0,1,'asdf','asdf','asdf@as.ua','28937498','','asdf','asdf','','','','asdf','','asdf','','Украина',220,'АР Крым',3483,'','Наличные деньги','cash','asdf','asdf','','asdf','','asdf','','Украина',220,'АР Крым',3483,'','Самовывоз со склада магазина','pickup.pickup','',262.0000,0,0,0.0000,2,4,'UAH',1.00000000,'212.66.40.18','212.66.40.18','Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.10.289 Version/12.02','ru-RU,ru;q=0.9,en;q=0.8','2012-11-16 13:10:33','2012-11-16 13:10:33'),
(23,2,'INV-2012-00',0,'sachs','http://sachs.com.ua/',0,1,'Александр Алесандрович','Пархоменко','rainbow.dndz@gmail.com','0977904837','','Александр Алесандрович','Пархоменко','','','','ул. Краснозвездная, 40','','Днепродзержинск','','Украина',220,'Днепропетровская область',3484,'','Наличные деньги','cash','Александр Алесандрович','Пархоменко','','ул. Краснозвездная, 40','','Днепродзержинск','','Украина',220,'Днепропетровская область',3484,'','Доставка через Новую Почту','novaposhta.novaposhta','ул. Крирова 2-ой склад.',122.0000,17,0,0.0000,2,4,'UAH',1.00000000,'94.153.52.129','94.153.52.129','Mozilla/5.0 (Windows NT 5.1; rv:16.0) Gecko/20100101 Firefox/16.0','uk,ru;q=0.8,en-us;q=0.5,en;q=0.3','2012-11-19 08:17:33','2012-11-19 14:06:56'),
(24,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',12,1,'Сергей Анатольевич','Пиган','pigansergey@gmail.com','0663382949','','Сергей Анатольевич','Пиган','','','','ул. Мира 26, кв. 60','','Херсон','73000','Украина',220,'Николаевская область',3494,'','Наличные деньги','cash','Сергей Анатольевич','Пиган','','ул. Мира 26, кв. 60','','Херсон','73000','Украина',220,'Николаевская область',3494,'','Доставка через Новую Почту','novaposhta.novaposhta','',1576.0000,18,0,0.0000,2,4,'UAH',1.00000000,'93.79.237.148','93.79.237.148','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:20.0) Gecko/20100101 Firefox/20.0','ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3','2013-05-07 08:14:58','2013-05-07 08:16:15'),
(25,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',8,1,'Николай','Бабюк','babiuk-nik@mail.ru','0675836194','','Николай Валерьевич','Бабюк','СТО','','','Буковинская','','Черновцы','','Украина',220,'Черновицкая область',3482,'','Банковский перевод','bank_transfer','Николай','Бабюк','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Доставка через Новую Почту','novaposhta.novaposhta','Склад № 4 отправлять на Бабюк Рувим Николаевич +380675836194',1796.0000,0,0,0.0000,2,4,'UAH',1.00000000,'46.247.130.109','46.247.130.109','Mozilla/5.0 (Windows NT 5.1; rv:20.0) Gecko/20100101 Firefox/20.0','ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3','2013-05-14 13:53:48','2013-05-14 13:53:48'),
(26,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',8,1,'Николай','Бабюк','babiuk-nik@mail.ru','0675836194','','Рувим Николаевич','Бабюк','Новая почта скл № 4','','','Головна 200','','г.Черновцы','60214','Украина',220,'Черновицкая область',3482,'','Наличные деньги','cash','Николай','Бабюк','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Доставка через Новую Почту','novaposhta.novaposhta','',1796.0000,0,0,0.0000,2,4,'UAH',1.00000000,'46.247.151.253','46.247.151.253','Mozilla/5.0 (Windows NT 5.1; rv:20.0) Gecko/20100101 Firefox/20.0','ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3','2013-05-14 23:42:35','2013-05-14 23:42:35'),
(27,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',8,1,'Николай','Бабюк','babiuk-nik@mail.ru','0675836194','','Рувим Николаевич','Бабюк','Новая почта скл № 4','','','Головна 200','','г.Черновцы','60214','Украина',220,'Черновицкая область',3482,'','Наличные деньги','cash','Николай','Бабюк','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Доставка через Новую Почту','novaposhta.novaposhta','СКЛАД № 4 НА БАБЮК РУВИМА НИКОЛАЕВИЧА',1796.0000,18,0,0.0000,2,4,'UAH',1.00000000,'46.247.151.253','46.247.151.253','Mozilla/5.0 (Windows NT 5.1; rv:20.0) Gecko/20100101 Firefox/20.0','ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3','2013-05-14 23:43:22','2013-05-14 23:43:28'),
(28,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',14,1,'денис михайлович','лазаренко','gw-e@yandex.ru','0984503516','','денис михайлович','лазаренко','','','','50 лет октября','','кривой рог','','Украина',220,'Днепропетровская область',3484,'','Наличные деньги','cash','денис михайлович','лазаренко','','50 лет октября','','кривой рог','','Украина',220,'Днепропетровская область',3484,'','Доставка через Новую Почту','novaposhta.novaposhta','номер 5',636.0000,18,0,0.0000,2,4,'UAH',1.00000000,'176.116.66.116','176.116.66.116','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.4 (KHTML, like Gecko) Chrome/22.0.1105.412 YaBrowser/1.5.1105.412 Safari/537.4','ru,uk;q=0.8,en;q=0.6','2013-06-13 08:07:47','2013-06-13 08:07:51'),
(29,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',14,1,'денис михайлович','лазаренко','gw-e@yandex.ru','0984503516','','денис михайлович','лазаренко','','','','50 лет октября','','кривой рог','','Украина',220,'Днепропетровская область',3484,'','Наличные деньги','cash','денис михайлович','лазаренко','','50 лет октября','','кривой рог','','Украина',220,'Днепропетровская область',3484,'','Доставка через Новую Почту','novaposhta.novaposhta','',658.0000,18,0,0.0000,2,4,'UAH',1.00000000,'176.116.76.155','176.116.76.155','Mozilla/5.0 (Windows NT 5.1; rv:15.0) Gecko/20100101 Firefox/15.0.1','ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3','2013-06-21 17:49:10','2013-06-21 17:49:23'),
(30,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',0,1,'Микола Олегович','Любчак','newkakaxa@gmail.com','0634038919','','Микола Олегович','Любчак','','','','Кавалерідзе 21/36','','Львів','79066','Украина',220,'Львовская область',3493,'','Наличные деньги','cash','Микола Олегович','Любчак','','Кавалерідзе 21/36','','Львів','79066','Украина',220,'Львовская область',3493,'','Доставка через Новую Почту','novaposhta.novaposhta','6-те львівське відділення',253.0000,18,0,0.0000,2,4,'UAH',1.00000000,'94.231.68.195','94.231.68.195','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0','uk,ru;q=0.8,en-us;q=0.5,en;q=0.3','2013-06-22 13:03:03','2013-06-22 15:06:43'),
(31,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',18,1,'Олег Валериевич','Лановенко','olegshop@mail.ru','0958200086','','Олег Валериевич','Лановенко','','','','пер. Кияновский 3-7, оф. 202.','','Киев','','Украина',220,'Киевская область',3490,'','Банковский перевод','bank_transfer','Олег Валериевич','Лановенко','','пер. Кияновский 3-7, оф. 202.','','Киев','','Украина',220,'Киевская область',3490,'','Доставка через Новую Почту','novaposhta.novaposhta','склад №48',262.0000,18,0,0.0000,2,4,'UAH',1.00000000,'91.239.81.197','91.239.81.197','Opera/9.80 (Windows NT 6.1) Presto/2.12.388 Version/12.16','uk-UA,uk;q=0.9,en;q=0.8','2013-07-11 10:28:54','2013-07-11 10:30:57'),
(32,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',0,1,'Виталий Семёнович','Сивак','sws2275@yandex.ru','0987822374','','Виталий Семёнович','Сивак','','','','Комсомольская 18','','п.Завалье','','Украина',220,'Кировоградская область',3489,'','Банковский перевод','bank_transfer','Виталий Семёнович','Сивак','','Комсомольская 18','','п.Завалье','','Украина',220,'Кировоградская область',3489,'','Доставка через Новую Почту','novaposhta.novaposhta','',1154.0000,18,0,0.0000,2,4,'UAH',1.00000000,'195.222.126.26','195.222.126.26','Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36','ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4','2013-07-24 10:48:15','2013-07-24 10:51:01'),
(33,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',19,1,'Святослав Олегович','Пальчиков','pso_my@mail.ru','+380953869521','','Святослав Олегович','Пальчиков','Оливия','','','г. Николаев ул. Буденого 42','','Николаев','','Украина',220,'Николаевская область',3494,'','Наличные деньги','cash','Святослав Олегович','Пальчиков','Оливия','г. Николаев ул. Буденого 42','','Николаев','','Украина',220,'Николаевская область',3494,'','Доставка через Новую Почту','novaposhta.novaposhta','отделение №1',1634.0000,18,0,0.0000,2,4,'UAH',1.00000000,'212.92.237.197','212.92.237.197','Mozilla/5.0 (Windows NT 6.1; rv:22.0) Gecko/20100101 Firefox/22.0','ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3','2013-08-03 02:19:23','2013-08-03 02:20:05'),
(34,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',23,1,'Сергей Михайлович','Секеда','office@gammapromservice.com.ua','0675783970','','Сергей Михайлович','Секеда','ООО &quot;Гаммапромсервис&quot;','','','г. Харьков, ','ул. Ильинская 59, 155','г. Харьков','61093','Украина',220,'Харьковская область',3487,'','Наличные деньги','cash','Сергей Михайлович','Секеда','ООО &quot;Гаммапромсервис&quot;','г. Харьков, ','ул. Ильинская 59, 155','г. Харьков','61093','Украина',220,'Харьковская область',3487,'','Доставка через Новую Почту','novaposhta.novaposhta','склад №8',2043.0000,0,0,0.0000,2,4,'UAH',1.00000000,'178.150.141.226','178.150.141.226','Opera/9.80 (Windows NT 6.1; Edition Yx) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-08-13 11:42:17','2013-08-13 11:42:17'),
(35,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',23,1,'Сергей Михайлович','Секеда','office@gammapromservice.com.ua','0675783970','','Сергей Михайлович','Секеда','ООО &quot;Гаммапромсервис&quot;','','','г. Харьков, ','ул. Ильинская 59, 155','г. Харьков','61093','Украина',220,'Харьковская область',3487,'','Банковский перевод','bank_transfer','Сергей Михайлович','Секеда','ООО &quot;Гаммапромсервис&quot;','г. Харьков, ','ул. Ильинская 59, 155','г. Харьков','61093','Украина',220,'Харьковская область',3487,'','Доставка через Новую Почту','novaposhta.novaposhta','склад №8\nбезнал с НДС',2043.0000,18,0,0.0000,2,4,'UAH',1.00000000,'178.150.141.226','178.150.141.226','Opera/9.80 (Windows NT 6.1; Edition Yx) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-08-13 11:42:53','2013-08-13 11:43:18'),
(36,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',25,1,'Евгений Владимирович','Соловьёв','slvevg@mail.ru','0668148379','','Евгений Владимирович','Соловьёв','Новая почта','','','Симоненка 1','','Коломыя','78200','Украина',220,'Ивано-Франковская область',3486,'','Наличные деньги','cash','Евгений Владимирович','Соловьёв','Новая почта','Симоненка 1','','Коломыя','78200','Украина',220,'Ивано-Франковская область',3486,'','Доставка через Новую Почту','novaposhta.novaposhta','',1136.0000,0,0,0.0000,2,4,'UAH',1.00000000,'46.175.136.15','46.175.136.15','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.57 Safari/537.36','ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4','2013-08-25 01:04:51','2013-08-25 01:04:51'),
(37,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',25,1,'Евгений Владимирович','Соловьёв','slvevg@mail.ru','0668148379','','Евгений Владимирович','Соловьёв','Новая почта','','','Симоненка 1','','Коломыя','78200','Украина',220,'Ивано-Франковская область',3486,'','Наличные деньги','cash','Евгений Владимирович','Соловьёв','Новая почта','Симоненка 1','','Коломыя','78200','Украина',220,'Ивано-Франковская область',3486,'','Доставка через Новую Почту','novaposhta.novaposhta','',1136.0000,18,0,0.0000,2,4,'UAH',1.00000000,'46.175.136.15','46.175.136.15','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.57 Safari/537.36','ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4','2013-08-25 01:06:46','2013-08-25 01:07:07'),
(38,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',0,1,'Валерий','Храпач','valeriy.khrapach@gmail.com','0663235007','','Валерий','Храпач','','','','Станиславского','','Полтава','','Украина',220,'Полтавская область',3496,'','Наличные деньги','cash','Валерий','Храпач','','Станиславского','','Полтава','','Украина',220,'Полтавская область',3496,'','Доставка через Гюнсел','gunsel.gunsel','',1151.0000,18,0,0.0000,2,4,'UAH',1.00000000,'91.219.220.240','91.219.220.240','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0','uk,ru;q=0.8,en-us;q=0.5,en;q=0.3','2013-08-25 10:39:17','2013-08-25 10:39:31'),
(39,0,'INV-2012-00',0,'sachs','http://sachs.com.ua/',9,1,'Сергей Леонидович','Недавний','serezha72@bk.ru','0677689848','0523622224','Сергей Леонидович','Недавний','СТО','','','.ул.Егорова ','53а','Светловодск','27500','Украина',220,'Кировоградская область',3489,'','Банковский перевод','bank_transfer','Сергей Леонидович','Недавний','СТО','.ул.Егорова ','53а','Светловодск','27500','Украина',220,'Кировоградская область',3489,'','Доставка через Новую Почту','novaposhta.novaposhta','',267.0000,0,0,0.0000,2,4,'UAH',1.00000000,'212.66.40.18','212.66.40.18','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-10 12:39:53','2013-09-10 12:39:53'),
(40,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Оплата по безналичному расчету','cashless','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',1398.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 10:36:00','2013-09-11 10:36:00'),
(41,3,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Оплата по безналичному расчету','cashless','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',1398.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 10:36:49','2013-09-11 10:36:49'),
(42,4,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Оплата по безналичному расчету','cashless','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',1398.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 11:53:14','2013-09-11 11:53:14'),
(43,5,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Оплата по безналичному расчету','cashless','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',1398.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 11:55:25','2013-09-11 11:55:25'),
(44,6,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Оплата по безналичному расчету','cashless','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',1398.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 11:56:20','2013-09-11 11:56:20'),
(45,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Оплата по безналичному расчету','cashless','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',1398.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 12:05:00','2013-09-11 12:05:00'),
(46,7,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Оплата по безналичному расчету','cashless','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',1398.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 12:05:50','2013-09-11 12:05:50'),
(47,8,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Оплата по безналичному расчету','cashless','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',1398.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 12:07:52','2013-09-11 12:07:52'),
(48,9,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Оплата по безналичному расчету','cashless','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',1398.0000,19,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 12:08:37','2013-09-11 12:08:40'),
(49,10,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Оплата по безналичному расчету','cashless','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 13:31:56','2013-09-11 13:31:56'),
(50,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Предоплата','prepay','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Самовывоз из магазина','pickup.pickup','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 16:47:12','2013-09-11 16:47:12'),
(51,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Предоплата','prepay','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Самовывоз из магазина','pickup.pickup','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 16:52:14','2013-09-11 16:52:14'),
(52,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Предоплата','prepay','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 16:52:43','2013-09-11 16:52:43'),
(53,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Предоплата','prepay','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 17:02:00','2013-09-11 17:02:00'),
(54,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Предоплата','prepay','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 17:02:14','2013-09-11 17:02:14'),
(55,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Предоплата','prepay','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 17:02:38','2013-09-11 17:02:38'),
(56,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Предоплата','prepay','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Самовывоз из магазина','pickup.pickup','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 17:03:10','2013-09-11 17:03:10'),
(57,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Оплата по безналичному расчету','cashless','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Самовывоз из магазина','pickup.pickup','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 17:03:27','2013-09-11 17:03:27'),
(58,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Предоплата','prepay','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Самовывоз из магазина','pickup.pickup','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 17:03:33','2013-09-11 17:03:33'),
(59,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Предоплата','prepay','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 17:04:14','2013-09-11 17:04:14'),
(60,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Предоплата','prepay','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 17:05:04','2013-09-11 17:05:04'),
(61,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Предоплата','prepay','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 17:06:01','2013-09-11 17:06:01'),
(62,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Предоплата','prepay','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 17:06:17','2013-09-11 17:06:17'),
(63,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Предоплата','prepay','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 17:08:54','2013-09-11 17:08:54'),
(64,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Предоплата','prepay','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 17:09:07','2013-09-11 17:09:07'),
(65,0,'INV-2012-00',0,'sachs','http://sachs/',17,1,'Александр ','Езерский ','o.yezerskiy@tpk.ua','380673716027','','Александр ','Езерский ','ТПК','','','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Предоплата','prepay','Александр ','Езерский ','ТПК','Карбышева 2а/1','Karbychev 2a\\1','Луцк','43023','Украина',220,'Волынская область',3502,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-11 17:10:07','2013-09-11 17:10:07'),
(66,0,'INV-2012-00',0,'sachs','http://sachs/',8,1,'Николай','Бабюк','babiuk-nik@mail.ru','0675836194','','Николай','Бабюк','','','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Предоплата','prepay','Николай','Бабюк','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',690.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-12 09:46:05','2013-09-12 09:46:05'),
(67,0,'INV-2012-00',0,'sachs','http://sachs/',8,1,'Николай','Бабюк','babiuk-nik@mail.ru','0675836194','','Николай','Бабюк','','','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Предоплата','prepay','Николай','Бабюк','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','',690.0000,18,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-12 09:49:02','2013-09-12 09:49:07'),
(68,0,'INV-2012-00',0,'sachs','http://sachs/',8,1,'Николай','Бабюк','babiuk-nik@mail.ru','0675836194','','Николай','Бабюк','','','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Предоплата','prepay','Николай','Бабюк','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Самовывоз из магазина','pickup.pickup','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-12 09:51:39','2013-09-12 09:51:39'),
(69,0,'INV-2012-00',0,'sachs','http://sachs/',8,1,'Николай','Бабюк','babiuk-nik@mail.ru','0675836194','','Николай','Бабюк','','','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Предоплата','prepay','Николай','Бабюк','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Самовывоз из магазина','pickup.pickup','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-12 09:59:16','2013-09-12 09:59:16'),
(70,0,'INV-2012-00',0,'sachs','http://sachs/',8,1,'Николай','Бабюк','babiuk-nik@mail.ru','0675836194','','Николай','Бабюк','','','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Предоплата','prepay','Николай','Бабюк','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Самовывоз из магазина','pickup.pickup','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-12 10:00:02','2013-09-12 10:00:02'),
(71,0,'INV-2012-00',0,'sachs','http://sachs/',8,1,'Николай','Бабюк','babiuk-nik@mail.ru','0675836194','','Николай','Бабюк','','','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Предоплата','prepay','Николай','Бабюк','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Самовывоз из магазина','pickup.pickup','',588.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-12 10:34:37','2013-09-12 10:34:37'),
(72,0,'INV-2012-00',0,'sachs','http://sachs/',8,1,'Николай','Бабюк','babiuk-nik@mail.ru','0675836194','','Николай','Бабюк','','','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Предоплата','prepay','Николай','Бабюк','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Самовывоз из магазина','pickup.pickup','',588.0000,18,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-12 10:47:34','2013-09-12 10:51:59'),
(73,0,'INV-2012-00',0,'sachs','http://sachs/',8,1,'Николай','Бабюк','babiuk-nik@mail.ru','0675836194','','Николай','Бабюк','','','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Предоплата','prepay','Николай','Бабюк','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Самовывоз из магазина','pickup.pickup','',603.0000,18,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-12 10:55:25','2013-09-12 10:55:27'),
(74,0,'INV-2012-00',0,'sachs','http://sachs/',8,1,'Николай','Бабюк','babiuk-nik@mail.ru','0675836194','','Николай','Бабюк','','','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Предоплата','prepay','Николай','Бабюк','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Самовывоз из магазина','pickup.pickup','',682.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-12 10:56:33','2013-09-12 10:56:33'),
(75,0,'INV-2012-00',0,'sachs','http://sachs/',8,1,'Николай','Бабюк','babiuk-nik@mail.ru','0675836194','','Николай','Бабюк','','','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Предоплата','prepay','Николай','Бабюк','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','asdf',1521.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-12 13:16:00','2013-09-12 13:16:00'),
(76,0,'INV-2012-00',0,'sachs','http://sachs/',8,1,'Николай','Бабюк','babiuk-nik@mail.ru','0675836194','','Николай','Бабюк','','','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Предоплата','prepay','Николай','Бабюк','','Буковинская 7','','Вертянка','60214','Украина',220,'Черновицкая область',3482,'','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к з','delivery.delivery','asdf',1521.0000,0,0,0.0000,2,4,'UAH',1.00000000,'127.0.0.2','','Opera/9.80 (Windows NT 5.1) Presto/2.12.388 Version/12.16','ru-RU,ru;q=0.9,en;q=0.8','2013-09-12 13:19:24','2013-09-12 13:19:24')	;
#	TC`oc_order_download`utf8_bin	;
CREATE TABLE `oc_order_download` (
  `order_download_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `order_product_id` int(11) NOT NULL,
  `name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `filename` varchar(128) COLLATE utf8_bin NOT NULL DEFAULT '',
  `mask` varchar(128) COLLATE utf8_bin NOT NULL DEFAULT '',
  `remaining` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_download_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_order_field`utf8_general_ci	;
CREATE TABLE `oc_order_field` (
  `order_id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `custom_field_value_id` int(11) NOT NULL,
  `name` int(128) NOT NULL,
  `value` text NOT NULL,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`order_id`,`custom_field_id`,`custom_field_value_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_order_fraud`utf8_bin	;
CREATE TABLE `oc_order_fraud` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `country_match` varchar(3) COLLATE utf8_bin NOT NULL,
  `country_code` varchar(2) COLLATE utf8_bin NOT NULL,
  `high_risk_country` varchar(3) COLLATE utf8_bin NOT NULL,
  `distance` int(11) NOT NULL,
  `ip_region` varchar(255) COLLATE utf8_bin NOT NULL,
  `ip_city` varchar(255) COLLATE utf8_bin NOT NULL,
  `ip_latitude` decimal(10,6) NOT NULL,
  `ip_longitude` decimal(10,6) NOT NULL,
  `ip_isp` varchar(255) COLLATE utf8_bin NOT NULL,
  `ip_org` varchar(255) COLLATE utf8_bin NOT NULL,
  `ip_asnum` int(11) NOT NULL,
  `ip_user_type` varchar(255) COLLATE utf8_bin NOT NULL,
  `ip_country_confidence` varchar(3) COLLATE utf8_bin NOT NULL,
  `ip_region_confidence` varchar(3) COLLATE utf8_bin NOT NULL,
  `ip_city_confidence` varchar(3) COLLATE utf8_bin NOT NULL,
  `ip_postal_confidence` varchar(3) COLLATE utf8_bin NOT NULL,
  `ip_postal_code` varchar(10) COLLATE utf8_bin NOT NULL,
  `ip_accuracy_radius` int(11) NOT NULL,
  `ip_net_speed_cell` varchar(255) COLLATE utf8_bin NOT NULL,
  `ip_metro_code` int(3) NOT NULL,
  `ip_area_code` int(3) NOT NULL,
  `ip_time_zone` varchar(255) COLLATE utf8_bin NOT NULL,
  `ip_region_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `ip_domain` varchar(255) COLLATE utf8_bin NOT NULL,
  `ip_country_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `ip_continent_code` varchar(2) COLLATE utf8_bin NOT NULL,
  `ip_corporate_proxy` varchar(3) COLLATE utf8_bin NOT NULL,
  `anonymous_proxy` varchar(3) COLLATE utf8_bin NOT NULL,
  `proxy_score` int(3) NOT NULL,
  `is_trans_proxy` varchar(3) COLLATE utf8_bin NOT NULL,
  `free_mail` varchar(3) COLLATE utf8_bin NOT NULL,
  `carder_email` varchar(3) COLLATE utf8_bin NOT NULL,
  `high_risk_username` varchar(3) COLLATE utf8_bin NOT NULL,
  `high_risk_password` varchar(3) COLLATE utf8_bin NOT NULL,
  `bin_match` varchar(10) COLLATE utf8_bin NOT NULL,
  `bin_country` varchar(2) COLLATE utf8_bin NOT NULL,
  `bin_name_match` varchar(3) COLLATE utf8_bin NOT NULL,
  `bin_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `bin_phone_match` varchar(3) COLLATE utf8_bin NOT NULL,
  `bin_phone` varchar(32) COLLATE utf8_bin NOT NULL,
  `customer_phone_in_billing_location` varchar(8) COLLATE utf8_bin NOT NULL,
  `ship_forward` varchar(3) COLLATE utf8_bin NOT NULL,
  `city_postal_match` varchar(3) COLLATE utf8_bin NOT NULL,
  `ship_city_postal_match` varchar(3) COLLATE utf8_bin NOT NULL,
  `score` decimal(10,5) NOT NULL,
  `explanation` text COLLATE utf8_bin NOT NULL,
  `risk_score` decimal(10,5) NOT NULL,
  `queries_remaining` int(11) NOT NULL,
  `maxmind_id` varchar(8) COLLATE utf8_bin NOT NULL,
  `error` text COLLATE utf8_bin NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_order_history`utf8_bin	;
CREATE TABLE `oc_order_history` (
  `order_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `order_status_id` int(5) NOT NULL,
  `notify` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_bin NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`order_history_id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TD`oc_order_history`utf8_bin	;
INSERT INTO `oc_order_history` VALUES 
(3,19,18,1,'Инструкции по банковскому переводу\n\nРеквизиты для частных лиц, а также юр. лиц неплательщиков НДС:\r\n\r\nФЛП Кравцов Олег Геннадьевич ЕГРПОУ: 2504700472\r\nчастный предприниматель на едином налоге, неплательщик НДС\r\nр/с 26001962487710 в ПАТ ПУБМ МФО 334851\r\n\r\n\r\n\r\nТакже Вы можете перевести нам средства на кредитные карты (карточные счета):\r\n\r\nПриватБанк ГРН № карты 6762 4620 5216 0204\r\nПУМБ ГРН № карты 4314 3723 0009 0962\r\nУниверсал Банк ГРН № счета 2620 4000 4429 31\r\n\r\n\r\n\r\nРеквизиты для юр. лиц плательщиков НДС: \r\n\r\nООО &quot;КОМПАНИЯ ТЕСМА&quot;\r\nЕДРПОУ 34899101, тел.(062) 385-68-86\r\nРСЧ 26002962484541 в ПАО &quot;ПУМБ&quot; МФО 334851\r\n ИНН 348991005643, номер свидетельства 100021148\r\n Является плательщиком налога на прибыль на общих основаниях\r\nАдрес 83007, г.Донецк, ул.Буслаева, 10\n\nЗаказ не будет обработан, пока деньги не поступят на наш расчетный счёт.','2012-11-12 12:24:33'),
(4,20,1,1,'','2012-11-14 15:42:02'),
(6,23,18,1,'','2012-11-19 08:17:36'),
(7,23,17,1,'','2012-11-19 13:04:44'),
(8,23,17,1,'озвучил TRV с автохатки 122 грн примерно из европы ','2012-11-19 13:05:42'),
(9,23,17,1,'','2012-11-19 14:06:56'),
(10,24,18,1,'','2013-05-07 08:16:15'),
(11,27,18,1,'','2013-05-14 23:43:28'),
(12,28,18,1,'','2013-06-13 08:07:51'),
(13,29,18,1,'','2013-06-21 17:49:23'),
(14,30,18,1,'','2013-06-22 13:03:09'),
(15,30,18,1,'Недостпен Ваш телефон.\nПерезвоните пожалуйста для согласования заказа\n0506929418\nИгорь','2013-06-22 13:38:36'),
(16,31,18,1,'Инструкции по банковскому переводу\n\nРеквизиты для частных лиц, а также юр. лиц неплательщиков НДС:\r\n\r\nФЛП Кравцов Олег Геннадьевич ЕГРПОУ: 2504700472\r\nчастный предприниматель на едином налоге, неплательщик НДС\r\nр/с 26001962487710 в ПАТ ПУБМ МФО 334851\r\n\r\n\r\n\r\nТакже Вы можете перевести нам средства на кредитные карты (карточные счета):\r\n\r\nПриватБанк ГРН № карты 6762 4620 5216 0204\r\nПУМБ ГРН № карты 4314 3723 0009 0962\r\nУниверсал Банк ГРН № счета 2620 4000 4429 31\r\n\r\n\r\n\r\nРеквизиты для юр. лиц плательщиков НДС: \r\n\r\nООО &quot;КОМПАНИЯ ТЕСМА&quot;\r\nЕДРПОУ 34899101, тел.(062) 385-68-86\r\nРСЧ 26002962484541 в ПАО &quot;ПУМБ&quot; МФО 334851\r\n ИНН 348991005643, номер свидетельства 100021148\r\n Является плательщиком налога на прибыль на общих основаниях\r\nАдрес 83007, г.Донецк, ул.Буслаева, 10\n\nЗаказ не будет обработан, пока деньги не поступят на наш расчетный счёт.','2013-07-11 10:30:57'),
(17,32,18,1,'Инструкции по банковскому переводу\n\nРеквизиты для частных лиц, а также юр. лиц неплательщиков НДС:\r\n\r\nФЛП Кравцов Олег Геннадьевич ЕГРПОУ: 2504700472\r\nчастный предприниматель на едином налоге, неплательщик НДС\r\nр/с 26001962487710 в ПАТ ПУБМ МФО 334851\r\n\r\n\r\n\r\nТакже Вы можете перевести нам средства на кредитные карты (карточные счета):\r\n\r\nПриватБанк ГРН № карты 6762 4620 5216 0204\r\nПУМБ ГРН № карты 4314 3723 0009 0962\r\nУниверсал Банк ГРН № счета 2620 4000 4429 31\r\n\r\n\r\n\r\nРеквизиты для юр. лиц плательщиков НДС: \r\n\r\nООО &quot;КОМПАНИЯ ТЕСМА&quot;\r\nЕДРПОУ 34899101, тел.(062) 385-68-86\r\nРСЧ 26002962484541 в ПАО &quot;ПУМБ&quot; МФО 334851\r\n ИНН 348991005643, номер свидетельства 100021148\r\n Является плательщиком налога на прибыль на общих основаниях\r\nАдрес 83007, г.Донецк, ул.Буслаева, 10\n\nЗаказ не будет обработан, пока деньги не поступят на наш расчетный счёт.','2013-07-24 10:51:01'),
(18,33,18,1,'','2013-08-03 02:20:05'),
(19,35,18,1,'Инструкции по банковскому переводу\n\nРеквизиты для частных лиц, а также юр. лиц неплательщиков НДС:\r\n\r\nФЛП Кравцов Олег Геннадьевич ЕГРПОУ: 2504700472\r\nчастный предприниматель на едином налоге, неплательщик НДС\r\nр/с 26001962487710 в ПАТ ПУБМ МФО 334851\r\n\r\n\r\n\r\nТакже Вы можете перевести нам средства на кредитные карты (карточные счета):\r\n\r\nПриватБанк ГРН № карты 6762 4620 5216 0204\r\nПУМБ ГРН № карты 4314 3723 0009 0962\r\nУниверсал Банк ГРН № счета 2620 4000 4429 31\r\n\r\n\r\n\r\nРеквизиты для юр. лиц плательщиков НДС: \r\n\r\nООО &quot;КОМПАНИЯ ТЕСМА&quot;\r\nЕДРПОУ 34899101, тел.(062) 385-68-86\r\nРСЧ 26002962484541 в ПАО &quot;ПУМБ&quot; МФО 334851\r\n ИНН 348991005643, номер свидетельства 100021148\r\n Является плательщиком налога на прибыль на общих основаниях\r\nАдрес 83007, г.Донецк, ул.Буслаева, 10\n\nЗаказ не будет обработан, пока деньги не поступят на наш расчетный счёт.','2013-08-13 11:43:18'),
(20,37,18,1,'','2013-08-25 01:07:07'),
(21,38,18,1,'','2013-08-25 10:39:31'),
(22,48,19,1,'Для печати Счета нажмите на кнопку <strong>Печать Счета</strong> (откроется в новом окне)\n\n<a href=\"http://sachs/index.php?route=payment/cashless/printpay&amp;order_id=48\" class=\"button\" style=\"text-decoration:none;\" target=\"_blank\"><span>Печать Счета</span></a>\n\nЗаказ не будет обработан, пока деньги не поступят на наш расчетный счёт.','2013-09-11 12:08:40'),
(23,67,18,1,'\n\n','2013-09-12 09:49:07'),
(24,72,18,1,'fuck :)','2013-09-12 10:51:59'),
(25,73,18,1,'Предоплата','2013-09-12 10:55:27')	;
#	TC`oc_order_misc`utf8_bin	;
CREATE TABLE `oc_order_misc` (
  `order_id` int(11) NOT NULL,
  `key` varchar(64) COLLATE utf8_bin NOT NULL,
  `value` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`order_id`,`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_order_option`utf8_bin	;
CREATE TABLE `oc_order_option` (
  `order_option_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `order_product_id` int(11) NOT NULL,
  `product_option_id` int(11) NOT NULL,
  `product_option_value_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `value` text COLLATE utf8_bin NOT NULL,
  `type` varchar(32) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`order_option_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_order_product`utf8_bin	;
CREATE TABLE `oc_order_product` (
  `order_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `model` varchar(64) COLLATE utf8_bin NOT NULL,
  `quantity` int(4) NOT NULL,
  `price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `total` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `tax` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `reward` int(8) NOT NULL,
  PRIMARY KEY (`order_product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=104	;
#	TD`oc_order_product`utf8_bin	;
INSERT INTO `oc_order_product` VALUES 
(1,1,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,0.0000,0),
(2,2,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,0.0000,0),
(3,3,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,0.0000,0),
(4,4,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,0.0000,0),
(5,5,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,0.0000,0),
(6,6,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,0.0000,0),
(8,8,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,0.0000,0),
(9,9,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,0.0000,0),
(10,10,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,0.0000,0),
(11,11,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,0.0000,0),
(12,12,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,0.0000,0),
(13,13,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,0.0000,0),
(14,14,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,0.0000,0),
(15,15,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,0.0000,0),
(16,16,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,6.1000,0),
(17,17,50,'FH23028 топливный сепаратор Fuel Pro','FH23028',1,122.0000,122.0000,6.1000,0),
(19,19,17501,'SACHS Комплект сцепления SACHS 3000 758 001','SACHS 3000 758 001',1,2736.0000,2736.0000,0.0000,0),
(20,20,20940,'SACHS Цилиндр сцепления робочий, MB W201 W124 89- SH 6283 600 112','SH 6283 600 112',1,265.0000,265.0000,0.0000,0),
(21,21,20350,'SACHS Рабочий цилиндр сцепления SACHS 6283 000 045','SACHS 6283 000 045',1,262.0000,262.0000,0.0000,0),
(23,23,28412,'SACHS Трос сцепления, FORD FIESTA III -95 SH 3074 600 293','SH 3074 600 293',1,122.0000,122.0000,0.0000,0),
(24,24,766,'SACHS SH 312 609','SH 312 609',1,783.0000,783.0000,0.0000,0),
(25,24,767,'SACHS SH 312 610','SH 312 610',1,793.0000,793.0000,0.0000,0),
(26,25,1450,'BOGE BG 32-H07-A','BG 32-H07-A',2,898.0000,1796.0000,0.0000,0),
(27,26,1450,'BOGE BG 32-H07-A','BG 32-H07-A',2,898.0000,1796.0000,0.0000,0),
(28,27,1450,'BOGE BG 32-H07-A','BG 32-H07-A',2,898.0000,1796.0000,0.0000,0),
(29,28,1180,'BOGE BG 27-201-F','BG 27-201-F',2,318.0000,636.0000,0.0000,0),
(30,29,1387,'BOGE BG 32-873-F','BG 32-873-F',2,329.0000,658.0000,0.0000,0),
(31,30,1088,'SACHS SH 802 459','SH 802 459',1,253.0000,253.0000,0.0000,0),
(32,31,3385,'SACHS SH 900 216','SH 900 216',1,262.0000,262.0000,0.0000,0),
(33,32,3096,'SACHS 313 908','313 908',2,577.0000,1154.0000,0.0000,0),
(34,33,3592,'BOGE BG 36-G63-A','BG 36-G63-A',2,817.0000,1634.0000,0.0000,0),
(35,34,2798,'SACHS 3000 951 899','3000 951 899',1,2043.0000,2043.0000,0.0000,0),
(36,35,2798,'SACHS 3000 951 899','3000 951 899',1,2043.0000,2043.0000,0.0000,0),
(37,36,1325,'BOGE BG 30-H39-A','BG 30-H39-A',2,568.0000,1136.0000,0.0000,0),
(38,37,1325,'BOGE BG 30-H39-A','BG 30-H39-A',2,568.0000,1136.0000,0.0000,0),
(39,38,1247,'BOGE BG 27-I12-A','BG 27-I12-A',2,473.0000,946.0000,0.0000,0),
(40,38,3388,'SACHS 900 233','900 233',1,205.0000,205.0000,0.0000,0),
(41,39,990,'SACHS SH 6283 000 045','SH 6283 000 045',1,267.0000,267.0000,0.0000,0),
(42,40,1694,'BOGE BG 36-F47-A','BG 36-F47-A',2,699.0000,1398.0000,0.0000,0),
(43,41,1694,'BOGE BG 36-F47-A','BG 36-F47-A',2,699.0000,1398.0000,0.0000,0),
(44,42,1694,'BOGE BG 36-F47-A','BG 36-F47-A',2,699.0000,1398.0000,0.0000,0),
(45,43,1694,'BOGE BG 36-F47-A','BG 36-F47-A',2,699.0000,1398.0000,0.0000,0),
(46,44,1694,'BOGE BG 36-F47-A','BG 36-F47-A',2,699.0000,1398.0000,0.0000,0),
(47,45,1694,'BOGE BG 36-F47-A','BG 36-F47-A',2,699.0000,1398.0000,0.0000,0),
(48,46,1694,'BOGE BG 36-F47-A','BG 36-F47-A',2,699.0000,1398.0000,0.0000,0),
(49,47,1694,'BOGE BG 36-F47-A','BG 36-F47-A',2,699.0000,1398.0000,0.0000,0),
(50,48,1694,'BOGE BG 36-F47-A','BG 36-F47-A',2,699.0000,1398.0000,0.0000,0),
(51,49,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(52,50,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(53,51,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(54,52,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(55,53,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(56,54,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(57,55,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(58,56,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(59,57,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(60,58,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(61,59,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(62,60,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(63,61,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(64,62,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(65,63,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(66,64,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(67,65,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(68,66,2378,'SACHS 100 352','100 352',1,690.0000,690.0000,0.0000,0),
(69,67,2378,'SACHS 100 352','100 352',1,690.0000,690.0000,0.0000,0),
(70,68,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(71,69,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(72,70,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(73,71,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(74,72,2376,'SACHS 100 274','100 274',1,588.0000,588.0000,0.0000,0),
(75,73,2382,'SACHS 100 591','100 591',1,603.0000,603.0000,0.0000,0),
(76,74,2280,'BOGE 32-124-0','32-124-0',1,682.0000,682.0000,0.0000,0),
(77,75,2280,'BOGE 32-124-0','32-124-0',1,682.0000,682.0000,0.0000,0),
(78,75,4,'SACHS 100 388','100 388',1,839.0000,839.0000,0.0000,0),
(79,76,2280,'BOGE 32-124-0','32-124-0',1,682.0000,682.0000,0.0000,0),
(80,76,4,'SACHS 100 388','100 388',1,839.0000,839.0000,0.0000,0)	;
#	TC`oc_order_recurring`utf8_general_ci	;
CREATE TABLE `oc_order_recurring` (
  `order_recurring_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `profile_id` int(11) NOT NULL,
  `profile_name` varchar(255) NOT NULL,
  `profile_description` varchar(255) NOT NULL,
  `recurring_frequency` varchar(25) NOT NULL,
  `recurring_cycle` smallint(6) NOT NULL,
  `recurring_duration` smallint(6) NOT NULL,
  `recurring_price` decimal(10,4) NOT NULL,
  `trial` tinyint(1) NOT NULL,
  `trial_frequency` varchar(25) NOT NULL,
  `trial_cycle` smallint(6) NOT NULL,
  `trial_duration` smallint(6) NOT NULL,
  `trial_price` decimal(10,4) NOT NULL,
  `profile_reference` varchar(255) NOT NULL,
  PRIMARY KEY (`order_recurring_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_order_recurring_transaction`utf8_general_ci	;
CREATE TABLE `oc_order_recurring_transaction` (
  `order_recurring_transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_recurring_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `amount` decimal(10,4) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`order_recurring_transaction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_order_status`utf8_bin	;
CREATE TABLE `oc_order_status` (
  `order_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `language_id` int(11) NOT NULL,
  `name` varchar(32) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`order_status_id`,`language_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=35	;
#	TD`oc_order_status`utf8_bin	;
INSERT INTO `oc_order_status` VALUES 
(20,2,'Деньги возвращены'),
(18,2,'В обработке'),
(21,2,'Отправлен'),
(19,2,'Доставлен и оплачен'),
(1,2,'Новый'),
(17,2,'Отменен'),
(22,2,'Отложен')	;
#	TC`oc_order_total`utf8_bin	;
CREATE TABLE `oc_order_total` (
  `order_total_id` int(10) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `code` varchar(32) COLLATE utf8_bin NOT NULL,
  `title` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `text` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `value` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`order_total_id`),
  KEY `idx_orders_total_orders_id` (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=231 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=95	;
#	TD`oc_order_total`utf8_bin	;
INSERT INTO `oc_order_total` VALUES 
(1,1,'sub_total','Сумма','122грн',122.0000,1),
(2,1,'shipping','Фиксированная стоимость доставки','5грн',5.0000,3),
(3,1,'total','Итого','127грн',127.0000,9),
(4,2,'sub_total','Сумма','122грн',122.0000,1),
(5,2,'shipping','Фиксированная стоимость доставки','5грн',5.0000,3),
(6,2,'total','Итого','127грн',127.0000,9),
(7,3,'sub_total','Сумма','122грн',122.0000,1),
(8,3,'shipping','Фиксированная стоимость доставки','5грн',5.0000,3),
(9,3,'total','Итого','127грн',127.0000,9),
(10,4,'sub_total','Сумма','122грн',122.0000,1),
(11,4,'shipping','Фиксированная стоимость доставки','5грн',5.0000,3),
(12,4,'total','Итого','127грн',127.0000,9),
(13,5,'sub_total','Сумма','122грн',122.0000,1),
(14,5,'shipping','Фиксированная стоимость доставки','5грн',5.0000,3),
(15,5,'total','Итого','127грн',127.0000,9),
(16,6,'sub_total','Сумма','122грн',122.0000,1),
(17,6,'shipping','Фиксированная стоимость доставки','5грн',5.0000,3),
(18,6,'total','Итого','127грн',127.0000,9),
(22,8,'sub_total','Сумма','122грн',122.0000,1),
(23,8,'shipping','Фиксированная стоимость доставки','5грн',5.0000,3),
(24,8,'total','Итого','127грн',127.0000,9),
(25,9,'sub_total','Сумма','122грн',122.0000,1),
(26,9,'shipping','Фиксированная стоимость доставки','5грн',5.0000,3),
(27,9,'total','Итого','127грн',127.0000,9),
(28,10,'sub_total','Сумма','122грн',122.0000,1),
(29,10,'shipping','Фиксированная стоимость доставки','5грн',5.0000,3),
(30,10,'total','Итого','127грн',127.0000,9),
(31,11,'sub_total','Сумма','122грн',122.0000,1),
(32,11,'shipping','Фиксированная стоимость доставки','5грн',5.0000,3),
(33,11,'total','Итого','127грн',127.0000,9),
(34,12,'sub_total','Сумма','122грн',122.0000,1),
(35,12,'shipping','Фиксированная стоимость доставки','5грн',5.0000,3),
(36,12,'total','Итого','127грн',127.0000,9),
(37,13,'sub_total','Сумма','122грн',122.0000,1),
(38,13,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0грн',0.0000,3),
(39,13,'total','Итого','122грн',122.0000,9),
(40,14,'sub_total','Сумма','122грн',122.0000,1),
(41,14,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0грн',0.0000,3),
(42,14,'total','Итого','122грн',122.0000,9),
(43,15,'sub_total','Сумма','122грн',122.0000,1),
(44,15,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0грн',0.0000,3),
(45,15,'total','Итого','122грн',122.0000,9),
(46,16,'sub_total','Сумма','122грн',122.0000,1),
(47,16,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0грн',0.0000,3),
(48,16,'tax','Наложенный платеж','6грн',6.1000,5),
(49,16,'total','Итого','128грн',128.1000,9),
(50,17,'sub_total','Сумма','122грн',122.0000,1),
(51,17,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0грн',0.0000,3),
(52,17,'tax','Наложенный платеж','6грн',6.1000,5),
(53,17,'total','Итого','128грн',128.1000,9),
(57,19,'sub_total','Сумма','2736 грн',2736.0000,1),
(58,19,'shipping','Самовывоз из магазина','0 грн',0.0000,3),
(59,19,'total','Итого','2736 грн',2736.0000,9),
(60,20,'sub_total','Сумма','265 грн',265.0000,1),
(61,20,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(62,20,'total','Итого','265 грн',265.0000,9),
(63,21,'sub_total','Сумма','262 грн',262.0000,1),
(64,21,'shipping','Самовывоз со склада магазина','0 грн',0.0000,3),
(65,21,'total','Итого','262 грн',262.0000,9),
(70,23,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(69,23,'sub_total','Сумма','122 грн',122.0000,1),
(71,23,'total','Итого','122 грн',122.0000,9),
(72,24,'sub_total','Сумма','1576 грн',1576.0000,1),
(73,24,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(74,24,'total','Итого','1576 грн',1576.0000,9),
(75,25,'sub_total','Сумма','1796 грн',1796.0000,1),
(76,25,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(77,25,'total','Итого','1796 грн',1796.0000,9),
(78,26,'sub_total','Сумма','1796 грн',1796.0000,1),
(79,26,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(80,26,'total','Итого','1796 грн',1796.0000,9),
(81,27,'sub_total','Сумма','1796 грн',1796.0000,1),
(82,27,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(83,27,'total','Итого','1796 грн',1796.0000,9),
(84,28,'sub_total','Сумма','636 грн',636.0000,1),
(85,28,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(86,28,'total','Итого','636 грн',636.0000,9),
(87,29,'sub_total','Сумма','658 грн',658.0000,1),
(88,29,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(89,29,'total','Итого','658 грн',658.0000,9),
(91,30,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(90,30,'sub_total','Сумма','253 грн',253.0000,1),
(92,30,'total','Итого','253 грн',253.0000,9),
(93,31,'sub_total','Сумма','262 грн',262.0000,1),
(94,31,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(95,31,'total','Итого','262 грн',262.0000,9),
(96,32,'sub_total','Сумма','1154 грн',1154.0000,1),
(97,32,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(98,32,'total','Итого','1154 грн',1154.0000,9),
(99,33,'sub_total','Сумма','1634 грн',1634.0000,1),
(100,33,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(101,33,'total','Итого','1634 грн',1634.0000,9),
(102,34,'sub_total','Сумма','2043 грн',2043.0000,1),
(103,34,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(104,34,'total','Итого','2043 грн',2043.0000,9),
(105,35,'sub_total','Сумма','2043 грн',2043.0000,1),
(106,35,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(107,35,'total','Итого','2043 грн',2043.0000,9),
(108,36,'sub_total','Сумма','1136 грн',1136.0000,1),
(109,36,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(110,36,'total','Итого','1136 грн',1136.0000,9),
(111,37,'sub_total','Сумма','1136 грн',1136.0000,1),
(112,37,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(113,37,'total','Итого','1136 грн',1136.0000,9),
(114,38,'sub_total','Сумма','1151 грн',1151.0000,1),
(115,38,'shipping','Доставка через Гюнсел','0 грн',0.0000,3),
(116,38,'total','Итого','1151 грн',1151.0000,9),
(117,39,'sub_total','Сумма','267 грн',267.0000,1),
(118,39,'shipping','Доставка через Новую Почту','0 грн',0.0000,3),
(119,39,'total','Итого','267 грн',267.0000,9),
(120,40,'sub_total','Сумма','1,398 грн',1398.0000,1),
(121,40,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(122,40,'total','Итого','1,398 грн',1398.0000,9),
(123,41,'sub_total','Сумма','1,398 грн',1398.0000,1),
(124,41,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(125,41,'total','Итого','1,398 грн',1398.0000,9),
(126,42,'sub_total','Сумма','1,398 грн',1398.0000,1),
(127,42,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(128,42,'total','Итого','1,398 грн',1398.0000,9),
(129,43,'sub_total','Сумма','1,398 грн',1398.0000,1),
(130,43,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(131,43,'total','Итого','1,398 грн',1398.0000,9),
(132,44,'sub_total','Сумма','1,398 грн',1398.0000,1),
(133,44,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(134,44,'total','Итого','1,398 грн',1398.0000,9),
(135,45,'sub_total','Сумма','1,398 грн',1398.0000,1),
(136,45,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(137,45,'total','Итого','1,398 грн',1398.0000,9),
(138,46,'sub_total','Сумма','1,398 грн',1398.0000,1),
(139,46,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(140,46,'total','Итого','1,398 грн',1398.0000,9),
(141,47,'sub_total','Сумма','1,398 грн',1398.0000,1),
(142,47,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(143,47,'total','Итого','1,398 грн',1398.0000,9),
(144,48,'sub_total','Сумма','1,398 грн',1398.0000,1),
(145,48,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(146,48,'total','Итого','1,398 грн',1398.0000,9),
(147,49,'sub_total','Сумма','588 грн',588.0000,1),
(148,49,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(149,49,'total','Итого','588 грн',588.0000,9),
(150,50,'sub_total','Сумма','588 грн',588.0000,1),
(151,50,'shipping','Самовывоз из магазина','0 грн',0.0000,3),
(152,50,'total','Итого','588 грн',588.0000,9),
(153,51,'sub_total','Сумма','588 грн',588.0000,1),
(154,51,'shipping','Самовывоз из магазина','0 грн',0.0000,3),
(155,51,'total','Итого','588 грн',588.0000,9),
(156,52,'sub_total','Сумма','588 грн',588.0000,1),
(157,52,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(158,52,'total','Итого','588 грн',588.0000,9),
(159,53,'sub_total','Сумма','588 грн',588.0000,1),
(160,53,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(161,53,'total','Итого','588 грн',588.0000,9),
(162,54,'sub_total','Сумма','588 грн',588.0000,1),
(163,54,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(164,54,'total','Итого','588 грн',588.0000,9),
(165,55,'sub_total','Сумма','588 грн',588.0000,1),
(166,55,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(167,55,'total','Итого','588 грн',588.0000,9),
(168,56,'sub_total','Сумма','588 грн',588.0000,1),
(169,56,'shipping','Самовывоз из магазина','0 грн',0.0000,3),
(170,56,'total','Итого','588 грн',588.0000,9),
(171,57,'sub_total','Сумма','588 грн',588.0000,1),
(172,57,'shipping','Самовывоз из магазина','0 грн',0.0000,3),
(173,57,'total','Итого','588 грн',588.0000,9),
(174,58,'sub_total','Сумма','588 грн',588.0000,1),
(175,58,'shipping','Самовывоз из магазина','0 грн',0.0000,3),
(176,58,'total','Итого','588 грн',588.0000,9),
(177,59,'sub_total','Сумма','588 грн',588.0000,1),
(178,59,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(179,59,'total','Итого','588 грн',588.0000,9),
(180,60,'sub_total','Сумма','588 грн',588.0000,1),
(181,60,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(182,60,'total','Итого','588 грн',588.0000,9),
(183,61,'sub_total','Сумма','588 грн',588.0000,1),
(184,61,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(185,61,'total','Итого','588 грн',588.0000,9),
(186,62,'sub_total','Сумма','588 грн',588.0000,1),
(187,62,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(188,62,'total','Итого','588 грн',588.0000,9),
(189,63,'sub_total','Сумма','588 грн',588.0000,1),
(190,63,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(191,63,'total','Итого','588 грн',588.0000,9),
(192,64,'sub_total','Сумма','588 грн',588.0000,1),
(193,64,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(194,64,'total','Итого','588 грн',588.0000,9),
(195,65,'sub_total','Сумма','588 грн',588.0000,1),
(196,65,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(197,65,'total','Итого','588 грн',588.0000,9),
(198,66,'sub_total','Сумма','690 грн',690.0000,1),
(199,66,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(200,66,'total','Итого','690 грн',690.0000,9),
(201,67,'sub_total','Сумма','690 грн',690.0000,1),
(202,67,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(203,67,'total','Итого','690 грн',690.0000,9),
(204,68,'sub_total','Сумма','588 грн',588.0000,1),
(205,68,'shipping','Самовывоз из магазина','0 грн',0.0000,3),
(206,68,'total','Итого','588 грн',588.0000,9),
(207,69,'sub_total','Сумма','588 грн',588.0000,1),
(208,69,'shipping','Самовывоз из магазина','0 грн',0.0000,3),
(209,69,'total','Итого','588 грн',588.0000,9),
(210,70,'sub_total','Сумма','588 грн',588.0000,1),
(211,70,'shipping','Самовывоз из магазина','0 грн',0.0000,3),
(212,70,'total','Итого','588 грн',588.0000,9),
(213,71,'sub_total','Сумма','588 грн',588.0000,1),
(214,71,'shipping','Самовывоз из магазина','0 грн',0.0000,3),
(215,71,'total','Итого','588 грн',588.0000,9),
(216,72,'sub_total','Сумма','588 грн',588.0000,1),
(217,72,'shipping','Самовывоз из магазина','0 грн',0.0000,3),
(218,72,'total','Итого','588 грн',588.0000,9),
(219,73,'sub_total','Сумма','603 грн',603.0000,1),
(220,73,'shipping','Самовывоз из магазина','0 грн',0.0000,3),
(221,73,'total','Итого','603 грн',603.0000,9),
(222,74,'sub_total','Сумма','682 грн',682.0000,1),
(223,74,'shipping','Самовывоз из магазина','0 грн',0.0000,3),
(224,74,'total','Итого','682 грн',682.0000,9),
(225,75,'sub_total','Сумма','1,521 грн',1521.0000,1),
(226,75,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(227,75,'total','Итого','1,521 грн',1521.0000,9),
(228,76,'sub_total','Сумма','1,521 грн',1521.0000,1),
(229,76,'shipping','Мы отправляем фирмами-перевозчиками: Новая почта, Деливери, Ин-тайм, Гюнсел, Автолюкс<br /><span class=\"help\">В комментариях к заказу укажите фирму-перевозчик и номер склада</span>','0 грн',0.0000,3),
(230,76,'total','Итого','1,521 грн',1521.0000,9)	;
#	TC`oc_order_voucher`utf8_bin	;
CREATE TABLE `oc_order_voucher` (
  `order_voucher_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `voucher_id` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8_bin NOT NULL,
  `code` varchar(10) COLLATE utf8_bin NOT NULL,
  `from_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `from_email` varchar(96) COLLATE utf8_bin NOT NULL,
  `to_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `to_email` varchar(96) COLLATE utf8_bin NOT NULL,
  `voucher_theme_id` int(11) NOT NULL,
  `message` text COLLATE utf8_bin NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  PRIMARY KEY (`order_voucher_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_product`utf8_bin	;
CREATE TABLE `oc_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(64) COLLATE utf8_bin NOT NULL,
  `sku` varchar(64) COLLATE utf8_bin NOT NULL,
  `upc` varchar(12) COLLATE utf8_bin NOT NULL,
  `ean` varchar(14) COLLATE utf8_bin NOT NULL,
  `jan` varchar(13) COLLATE utf8_bin NOT NULL,
  `isbn` varchar(13) COLLATE utf8_bin NOT NULL,
  `mpn` varchar(64) COLLATE utf8_bin NOT NULL,
  `location` varchar(128) COLLATE utf8_bin NOT NULL,
  `quantity` int(4) NOT NULL DEFAULT '0',
  `stock_status_id` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `manufacturer_id` int(11) NOT NULL,
  `shipping` tinyint(1) NOT NULL DEFAULT '1',
  `price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `points` int(8) NOT NULL DEFAULT '0',
  `tax_class_id` int(11) NOT NULL,
  `date_available` date NOT NULL,
  `weight` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `weight_class_id` int(11) NOT NULL DEFAULT '0',
  `length` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `width` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `height` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `length_class_id` int(11) NOT NULL DEFAULT '0',
  `subtract` tinyint(1) NOT NULL DEFAULT '1',
  `minimum` int(11) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `viewed` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_id`),
  KEY `sku` (`sku`),
  KEY `model` (`model`),
  KEY `stock_status_id` (`stock_status_id`),
  KEY `quantity` (`quantity`,`date_available`),
  KEY `tax_class_id` (`tax_class_id`,`weight_class_id`,`length_class_id`),
  KEY `sort_order` (`sort_order`)
) ENGINE=MyISAM AUTO_INCREMENT=4955 DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_product_attribute`utf8_bin	;
CREATE TABLE `oc_product_attribute` (
  `product_id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `text` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`product_id`,`attribute_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_product_description`utf8_bin	;
CREATE TABLE `oc_product_description` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `meta_description` varchar(255) COLLATE utf8_bin NOT NULL,
  `meta_keyword` varchar(255) COLLATE utf8_bin NOT NULL,
  `tag` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`product_id`,`language_id`),
  KEY `name` (`name`),
  FULLTEXT KEY `description` (`description`),
  FULLTEXT KEY `tag` (`tag`)
) ENGINE=MyISAM AUTO_INCREMENT=4955 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=392	;
#	TC`oc_product_discount`utf8_bin	;
CREATE TABLE `oc_product_discount` (
  `product_discount_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  `quantity` int(4) NOT NULL DEFAULT '0',
  `priority` int(5) NOT NULL DEFAULT '1',
  `price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `date_start` date NOT NULL DEFAULT '0000-00-00',
  `date_end` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`product_discount_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_product_filter`utf8_general_ci	;
CREATE TABLE `oc_product_filter` (
  `product_id` int(11) NOT NULL,
  `filter_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`filter_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_product_image`utf8_bin	;
CREATE TABLE `oc_product_image` (
  `product_image_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_image_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_product_option`utf8_bin	;
CREATE TABLE `oc_product_option` (
  `product_option_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `option_value` text COLLATE utf8_bin NOT NULL,
  `required` tinyint(1) NOT NULL,
  PRIMARY KEY (`product_option_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_product_option_value`utf8_bin	;
CREATE TABLE `oc_product_option_value` (
  `product_option_value_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_option_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `option_value_id` int(11) NOT NULL,
  `quantity` int(3) NOT NULL,
  `subtract` tinyint(1) NOT NULL,
  `price` decimal(15,4) NOT NULL,
  `price_prefix` varchar(1) COLLATE utf8_bin NOT NULL,
  `points` int(8) NOT NULL,
  `points_prefix` varchar(1) COLLATE utf8_bin NOT NULL,
  `weight` decimal(15,8) NOT NULL,
  `weight_prefix` varchar(1) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`product_option_value_id`),
  KEY `product_option_id` (`product_option_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_product_profile`utf8_general_ci	;
CREATE TABLE `oc_product_profile` (
  `product_id` int(11) NOT NULL,
  `profile_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`profile_id`,`customer_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_product_recurring`utf8_general_ci	;
CREATE TABLE `oc_product_recurring` (
  `product_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`store_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_product_related`utf8_bin	;
CREATE TABLE `oc_product_related` (
  `product_id` int(11) NOT NULL,
  `related_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`related_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_product_reward`utf8_bin	;
CREATE TABLE `oc_product_reward` (
  `product_reward_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL DEFAULT '0',
  `customer_group_id` int(11) NOT NULL DEFAULT '0',
  `points` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_reward_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=17	;
#	TC`oc_product_special`utf8_bin	;
CREATE TABLE `oc_product_special` (
  `product_special_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  `priority` int(5) NOT NULL DEFAULT '1',
  `price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `date_start` date NOT NULL DEFAULT '0000-00-00',
  `date_end` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`product_special_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_product_tag`utf8_bin	;
CREATE TABLE `oc_product_tag` (
  `product_tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `tag` varchar(32) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`product_tag_id`),
  KEY `language_id` (`language_id`),
  KEY `product_id` (`product_id`),
  KEY `tag` (`tag`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_product_to_category`utf8_bin	;
CREATE TABLE `oc_product_to_category` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=9	;
#	TC`oc_product_to_download`utf8_bin	;
CREATE TABLE `oc_product_to_download` (
  `product_id` int(11) NOT NULL,
  `download_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`download_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_product_to_layout`utf8_bin	;
CREATE TABLE `oc_product_to_layout` (
  `product_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`store_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_product_to_store`utf8_bin	;
CREATE TABLE `oc_product_to_store` (
  `product_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_id`,`store_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=9	;
#	TC`oc_profile`utf8_general_ci	;
CREATE TABLE `oc_profile` (
  `profile_id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `price` decimal(10,4) NOT NULL,
  `frequency` enum('day','week','semi_month','month','year') NOT NULL,
  `duration` int(10) unsigned NOT NULL,
  `cycle` int(10) unsigned NOT NULL,
  `trial_status` tinyint(4) NOT NULL,
  `trial_price` decimal(10,4) NOT NULL,
  `trial_frequency` enum('day','week','semi_month','month','year') NOT NULL,
  `trial_duration` int(10) unsigned NOT NULL,
  `trial_cycle` int(10) unsigned NOT NULL,
  PRIMARY KEY (`profile_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_profile_description`utf8_general_ci	;
CREATE TABLE `oc_profile_description` (
  `profile_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`profile_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_return`utf8_bin	;
CREATE TABLE `oc_return` (
  `return_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `firstname` varchar(32) COLLATE utf8_bin NOT NULL,
  `lastname` varchar(32) COLLATE utf8_bin NOT NULL,
  `email` varchar(96) COLLATE utf8_bin NOT NULL,
  `telephone` varchar(32) COLLATE utf8_bin NOT NULL,
  `product` varchar(255) COLLATE utf8_bin NOT NULL,
  `model` varchar(64) COLLATE utf8_bin NOT NULL,
  `quantity` int(4) NOT NULL,
  `opened` tinyint(1) NOT NULL,
  `return_reason_id` int(11) NOT NULL,
  `return_action_id` int(11) NOT NULL,
  `return_status_id` int(11) NOT NULL,
  `comment` text COLLATE utf8_bin,
  `date_ordered` date NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`return_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_return_action`utf8_bin	;
CREATE TABLE `oc_return_action` (
  `return_action_id` int(11) NOT NULL AUTO_INCREMENT,
  `language_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`return_action_id`,`language_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=28	;
#	TD`oc_return_action`utf8_bin	;
INSERT INTO `oc_return_action` VALUES 
(1,2,'Refunded'),
(2,2,'Credit Issued'),
(3,2,'Replacement Sent')	;
#	TC`oc_return_history`utf8_bin	;
CREATE TABLE `oc_return_history` (
  `return_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `return_id` int(11) NOT NULL,
  `return_status_id` int(11) NOT NULL,
  `notify` tinyint(1) NOT NULL,
  `comment` text COLLATE utf8_bin NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`return_history_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_return_reason`utf8_bin	;
CREATE TABLE `oc_return_reason` (
  `return_reason_id` int(11) NOT NULL AUTO_INCREMENT,
  `language_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(128) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`return_reason_id`,`language_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=50	;
#	TD`oc_return_reason`utf8_bin	;
INSERT INTO `oc_return_reason` VALUES 
(8,2,'Ошибка подбора'),
(6,2,'Повреждено при транспортировке'),
(7,2,'Ошибка заказа')	;
#	TC`oc_return_status`utf8_bin	;
CREATE TABLE `oc_return_status` (
  `return_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `language_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`return_status_id`,`language_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=25	;
#	TD`oc_return_status`utf8_bin	;
INSERT INTO `oc_return_status` VALUES 
(1,2,'Pending'),
(3,2,'Complete'),
(2,2,'Awaiting Products')	;
#	TC`oc_review`utf8_bin	;
CREATE TABLE `oc_review` (
  `review_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `author` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `text` text COLLATE utf8_bin NOT NULL,
  `rating` int(1) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`review_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_setting`utf8_general_ci	;
CREATE TABLE `oc_setting` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) NOT NULL,
  `group` varchar(32) NOT NULL,
  `key` varchar(64) NOT NULL,
  `value` text NOT NULL,
  `serialized` tinyint(1) NOT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2846 DEFAULT CHARSET=utf8	;
#	TD`oc_setting`utf8_general_ci	;
INSERT INTO `oc_setting` VALUES 
(1,0,'shipping','shipping_sort_order','3',0),
(2,0,'sub_total','sub_total_sort_order','1',0),
(3,0,'sub_total','sub_total_status','1',0),
(4,0,'tax','tax_status','1',0),
(5,0,'total','total_sort_order','9',0),
(6,0,'total','total_status','1',0),
(7,0,'tax','tax_sort_order','5',0),
(2638,0,'cod','cod_sort_order','5',0),
(2637,0,'cod','cod_status','1',0),
(2636,0,'cod','cod_geo_zone_id','0',0),
(14,0,'shipping','shipping_status','1',0),
(15,0,'shipping','shipping_estimator','1',0),
(827,0,'delivery','delivery_status','1',0),
(826,0,'pickup','pickup_sort_order','2',0),
(825,0,'pickup','pickup_status','1',0),
(1779,0,'featured','product','SACHS Рабочий цилиндр сцепления SACHS 6283 000 045',0),
(1780,0,'featured','featured_product','20350',0),
(1781,0,'featured','featured_module','a:1:{i:0;a:7:{s:5:\"limit\";s:1:\"6\";s:11:\"image_width\";s:2:\"80\";s:12:\"image_height\";s:2:\"80\";s:9:\"layout_id\";s:1:\"1\";s:8:\"position\";s:11:\"content_top\";s:6:\"status\";s:1:\"1\";s:10:\"sort_order\";s:1:\"2\";}}',1),
(824,0,'pickup','pickup_geo_zone_id','0',0),
(828,0,'delivery','delivery_sort_order','',0),
(60,0,'account','account_module','a:1:{i:0;a:4:{s:9:\"layout_id\";s:1:\"6\";s:8:\"position\";s:12:\"column_right\";s:6:\"status\";s:1:\"1\";s:10:\"sort_order\";s:1:\"1\";}}',1),
(2522,0,'config','config_google_analytics','',0),
(2521,0,'config','config_error_filename','error.txt',0),
(2520,0,'config','config_error_log','0',0),
(2518,0,'config','config_compression','2',0),
(2519,0,'config','config_error_display','1',0),
(2517,0,'config','config_encryption','v0sf8v1c2d5v398fh4cu8adx0ff6gkav',0),
(2516,0,'config','config_password','0',0),
(2635,0,'cod','cod_order_status_id','18',0),
(2634,0,'cod','cod_total','1000',0),
(2515,0,'config','config_maintenance','0',0),
(2514,0,'config','config_file_mime_allowed','',0),
(2513,0,'config','config_file_extension_allowed','',0),
(789,0,'bank_transfer','bank_transfer_bank_2','Реквизиты для частных лиц, а также юр. лиц неплательщиков НДС:\r\n\r\nФЛП Кравцов Олег Геннадьевич ЕГРПОУ: 2504700472\r\nчастный предприниматель на едином налоге, неплательщик НДС\r\nр/с 26001962487710 в ПАТ ПУБМ МФО 334851\r\n\r\n\r\n\r\nТакже Вы можете перевести нам средства на кредитные карты (карточные счета):\r\n\r\nПриватБанк ГРН № карты 6762 4620 5216 0204\r\nПУМБ ГРН № карты 4314 3723 0009 0962\r\nУниверсал Банк ГРН № счета 2620 4000 4429 31\r\n\r\n\r\n\r\nРеквизиты для юр. лиц плательщиков НДС: \r\n\r\nООО &quot;КОМПАНИЯ ТЕСМА&quot;\r\nЕДРПОУ 34899101, тел.(062) 385-68-86\r\nРСЧ 26002962484541 в ПАО &quot;ПУМБ&quot; МФО 334851\r\n ИНН 348991005643, номер свидетельства 100021148\r\n Является плательщиком налога на прибыль на общих основаниях\r\nАдрес 83007, г.Донецк, ул.Буслаева, 10',0),
(2512,0,'config','config_seo_url','1',0),
(2511,0,'config','config_robots','',0),
(2510,0,'config','config_shared','0',0),
(2509,0,'config','config_secure','0',0),
(2508,0,'config','config_fraud_status_id','18',0),
(2504,0,'config','config_alert_emails','',0),
(2505,0,'config','config_fraud_detection','0',0),
(2506,0,'config','config_fraud_key','',0),
(2507,0,'config','config_fraud_score','',0),
(2503,0,'config','config_account_mail','0',0),
(2502,0,'config','config_alert_mail','0',0),
(2500,0,'config','config_smtp_port','25',0),
(2501,0,'config','config_smtp_timeout','5',0),
(2499,0,'config','config_smtp_password','',0),
(2497,0,'config','config_smtp_host','',0),
(2498,0,'config','config_smtp_username','',0),
(2496,0,'config','config_mail_parameter','',0),
(2494,0,'config','config_ftp_status','0',0),
(2495,0,'config','config_mail_protocol','mail',0),
(2493,0,'config','config_ftp_root','',0),
(2492,0,'config','config_ftp_password','',0),
(2491,0,'config','config_ftp_username','',0),
(2482,0,'config','config_image_related_height','80',0),
(2483,0,'config','config_image_compare_width','90',0),
(2484,0,'config','config_image_compare_height','90',0),
(2485,0,'config','config_image_wishlist_width','47',0),
(2486,0,'config','config_image_wishlist_height','47',0),
(2487,0,'config','config_image_cart_width','47',0),
(2488,0,'config','config_image_cart_height','47',0),
(2489,0,'config','config_ftp_host','sachs',0),
(2490,0,'config','config_ftp_port','21',0),
(790,0,'bank_transfer','bank_transfer_total','',0),
(791,0,'bank_transfer','bank_transfer_order_status_id','18',0),
(792,0,'bank_transfer','bank_transfer_geo_zone_id','0',0),
(793,0,'bank_transfer','bank_transfer_status','1',0),
(794,0,'bank_transfer','bank_transfer_sort_order','1',0),
(2418,0,'contact','contact_data','a:3:{i:1;a:3:{s:4:\"info\";s:153:\"tel=+38 (050) 474-2119\r\ntel=+38 (096) 163-5626\r\ntel=+38 (093) 779-9311\r\ntel=+38 (062) 385-6150\r\nicq=361-967-545\r\nemail=parts@tesma.com.ua\r\nskype=triariya\";s:5:\"block\";s:1:\"1\";s:11:\"format_info\";s:1523:\"<table id=\"contact_info\"><tbody><tr><td><div class=\"sprites mts\"></div></td><td>+38 (050) 474-2119\r</td></tr><tr><td><div class=\"sprites kyivstar\"></div></td><td>+38 (096) 163-5626\r</td></tr><tr><td><div class=\"sprites life\"></div></td><td>+38 (093) 779-9311\r</td></tr><tr><td><div class=\"sprites phone\"></div></td><td>+38 (062) 385-6150\r</td></tr><tr><td><div class=\"sprites online\"></div></td><td>361-967-545</td></tr><tr><td><div class=\"sprites email\"></div></td><td><script type=\"text/javascript\">\r\n	//<![CDATA[\r\n	var l=new Array();\r\n	l[0]=\'>\';l[1]=\'a\';l[2]=\'/\';l[3]=\'<\';l[4]=\'|97\';l[5]=\'|117\';l[6]=\'|46\';l[7]=\'|109\';l[8]=\'|111\';l[9]=\'|99\';l[10]=\'|46\';l[11]=\'|97\';l[12]=\'|109\';l[13]=\'|115\';l[14]=\'|101\';l[15]=\'|116\';l[16]=\'|64\';l[17]=\'|115\';l[18]=\'|116\';l[19]=\'|114\';l[20]=\'|97\';l[21]=\'|112\';l[22]=\'>\';l[23]=\'\"\';l[24]=\'|97\';l[25]=\'|117\';l[26]=\'|46\';l[27]=\'|109\';l[28]=\'|111\';l[29]=\'|99\';l[30]=\'|46\';l[31]=\'|97\';l[32]=\'|109\';l[33]=\'|115\';l[34]=\'|101\';l[35]=\'|116\';l[36]=\'|64\';l[37]=\'|115\';l[38]=\'|116\';l[39]=\'|114\';l[40]=\'|97\';l[41]=\'|112\';l[42]=\':\';l[43]=\'o\';l[44]=\'t\';l[45]=\'l\';l[46]=\'i\';l[47]=\'a\';l[48]=\'m\';l[49]=\'\"\';l[50]=\'=\';l[51]=\'f\';l[52]=\'e\';l[53]=\'r\';l[54]=\'h\';l[55]=\' \';l[56]=\'a\';l[57]=\'<\';\r\n	for (var i = l.length-1; i >= 0; i=i-1){\r\n	if (l[i].substring(0, 1) == \'|\') document.write(\"&#\"+unescape(l[i].substring(1))+\";\");\r\n	else document.write(unescape(l[i]));}\r\n	//]]>\r\n	</script></td></tr><tr><td><div class=\"sprites skype\"></div></td><td><a href=\"skype:triariya?call\">triariya</a></td></tr></tbody></table>\";}i:2;a:3:{s:4:\"info\";s:155:\"tel=+38 (050) 478-2737\r\ntel=+38 (067) 621-4393\r\ntel=+38 (093) 779-9311\r\ntel=+38 (062) 385-6150\r\nicq=636-581-726\r\nemail=prom@tesma.com.ua\r\nskype=Denis_tesma\";s:5:\"block\";s:1:\"2\";s:11:\"format_info\";s:1505:\"<table id=\"contact_info\"><tbody><tr><td><div class=\"sprites mts\"></div></td><td>+38 (050) 478-2737\r</td></tr><tr><td><div class=\"sprites kyivstar\"></div></td><td>+38 (067) 621-4393\r</td></tr><tr><td><div class=\"sprites life\"></div></td><td>+38 (093) 779-9311\r</td></tr><tr><td><div class=\"sprites phone\"></div></td><td>+38 (062) 385-6150\r</td></tr><tr><td><div class=\"sprites online\"></div></td><td>636-581-726</td></tr><tr><td><div class=\"sprites email\"></div></td><td><script type=\"text/javascript\">\r\n	//<![CDATA[\r\n	var l=new Array();\r\n	l[0]=\'>\';l[1]=\'a\';l[2]=\'/\';l[3]=\'<\';l[4]=\'|97\';l[5]=\'|117\';l[6]=\'|46\';l[7]=\'|109\';l[8]=\'|111\';l[9]=\'|99\';l[10]=\'|46\';l[11]=\'|97\';l[12]=\'|109\';l[13]=\'|115\';l[14]=\'|101\';l[15]=\'|116\';l[16]=\'|64\';l[17]=\'|109\';l[18]=\'|111\';l[19]=\'|114\';l[20]=\'|112\';l[21]=\'>\';l[22]=\'\"\';l[23]=\'|97\';l[24]=\'|117\';l[25]=\'|46\';l[26]=\'|109\';l[27]=\'|111\';l[28]=\'|99\';l[29]=\'|46\';l[30]=\'|97\';l[31]=\'|109\';l[32]=\'|115\';l[33]=\'|101\';l[34]=\'|116\';l[35]=\'|64\';l[36]=\'|109\';l[37]=\'|111\';l[38]=\'|114\';l[39]=\'|112\';l[40]=\':\';l[41]=\'o\';l[42]=\'t\';l[43]=\'l\';l[44]=\'i\';l[45]=\'a\';l[46]=\'m\';l[47]=\'\"\';l[48]=\'=\';l[49]=\'f\';l[50]=\'e\';l[51]=\'r\';l[52]=\'h\';l[53]=\' \';l[54]=\'a\';l[55]=\'<\';\r\n	for (var i = l.length-1; i >= 0; i=i-1){\r\n	if (l[i].substring(0, 1) == \'|\') document.write(\"&#\"+unescape(l[i].substring(1))+\";\");\r\n	else document.write(unescape(l[i]));}\r\n	//]]>\r\n	</script></td></tr><tr><td><div class=\"sprites skype\"></div></td><td><a href=\"skype:Denis_tesma?call\">Denis_tesma</a></td></tr></tbody></table>\";}i:3;a:3:{s:4:\"info\";s:137:\"tel=+38 (050) 422-8955\r\ntel=+38 (067) 640-3149\r\ntel=+38 (093) 779-9311\r\ntel=+38 (062) 385-6150\r\nicq=606-366-041\r\nemail=zakaz@tesma.com.ua\";s:5:\"block\";s:1:\"3\";s:11:\"format_info\";s:1419:\"<table id=\"contact_info\"><tbody><tr><td><div class=\"sprites mts\"></div></td><td>+38 (050) 422-8955\r</td></tr><tr><td><div class=\"sprites kyivstar\"></div></td><td>+38 (067) 640-3149\r</td></tr><tr><td><div class=\"sprites life\"></div></td><td>+38 (093) 779-9311\r</td></tr><tr><td><div class=\"sprites phone\"></div></td><td>+38 (062) 385-6150\r</td></tr><tr><td><div class=\"sprites online\"></div></td><td>606-366-041</td></tr><tr><td><div class=\"sprites email\"></div></td><td><script type=\"text/javascript\">\r\n	//<![CDATA[\r\n	var l=new Array();\r\n	l[0]=\'>\';l[1]=\'a\';l[2]=\'/\';l[3]=\'<\';l[4]=\'|97\';l[5]=\'|117\';l[6]=\'|46\';l[7]=\'|109\';l[8]=\'|111\';l[9]=\'|99\';l[10]=\'|46\';l[11]=\'|97\';l[12]=\'|109\';l[13]=\'|115\';l[14]=\'|101\';l[15]=\'|116\';l[16]=\'|64\';l[17]=\'|122\';l[18]=\'|97\';l[19]=\'|107\';l[20]=\'|97\';l[21]=\'|122\';l[22]=\'>\';l[23]=\'\"\';l[24]=\'|97\';l[25]=\'|117\';l[26]=\'|46\';l[27]=\'|109\';l[28]=\'|111\';l[29]=\'|99\';l[30]=\'|46\';l[31]=\'|97\';l[32]=\'|109\';l[33]=\'|115\';l[34]=\'|101\';l[35]=\'|116\';l[36]=\'|64\';l[37]=\'|122\';l[38]=\'|97\';l[39]=\'|107\';l[40]=\'|97\';l[41]=\'|122\';l[42]=\':\';l[43]=\'o\';l[44]=\'t\';l[45]=\'l\';l[46]=\'i\';l[47]=\'a\';l[48]=\'m\';l[49]=\'\"\';l[50]=\'=\';l[51]=\'f\';l[52]=\'e\';l[53]=\'r\';l[54]=\'h\';l[55]=\' \';l[56]=\'a\';l[57]=\'<\';\r\n	for (var i = l.length-1; i >= 0; i=i-1){\r\n	if (l[i].substring(0, 1) == \'|\') document.write(\"&#\"+unescape(l[i].substring(1))+\";\");\r\n	else document.write(unescape(l[i]));}\r\n	//]]>\r\n	</script></td></tr></tbody></table>\";}}',1),
(2419,0,'contact','contact_module','a:6:{i:0;a:5:{s:4:\"show\";s:1:\"0\";s:9:\"layout_id\";s:1:\"7\";s:8:\"position\";s:9:\"my_header\";s:6:\"status\";s:1:\"1\";s:10:\"sort_order\";s:1:\"1\";}i:1;a:5:{s:4:\"show\";s:1:\"0\";s:9:\"layout_id\";s:1:\"8\";s:8:\"position\";s:9:\"my_header\";s:6:\"status\";s:1:\"1\";s:10:\"sort_order\";s:1:\"1\";}i:2;a:5:{s:4:\"show\";s:1:\"0\";s:9:\"layout_id\";s:2:\"11\";s:8:\"position\";s:9:\"my_header\";s:6:\"status\";s:1:\"1\";s:10:\"sort_order\";s:1:\"1\";}i:3;a:5:{s:4:\"show\";s:1:\"0\";s:9:\"layout_id\";s:1:\"2\";s:8:\"position\";s:9:\"my_header\";s:6:\"status\";s:1:\"1\";s:10:\"sort_order\";s:1:\"1\";}i:4;a:5:{s:4:\"show\";s:1:\"0\";s:9:\"layout_id\";s:1:\"3\";s:8:\"position\";s:9:\"my_header\";s:6:\"status\";s:1:\"1\";s:10:\"sort_order\";s:1:\"1\";}i:5;a:5:{s:4:\"show\";s:1:\"0\";s:9:\"layout_id\";s:1:\"1\";s:8:\"position\";s:9:\"my_header\";s:6:\"status\";s:1:\"1\";s:10:\"sort_order\";s:1:\"1\";}}',1),
(2481,0,'config','config_image_related_width','80',0),
(2480,0,'config','config_image_additional_height','74',0),
(2479,0,'config','config_image_additional_width','74',0),
(2478,0,'config','config_image_product_height','80',0),
(2477,0,'config','config_image_product_width','80',0),
(2476,0,'config','config_image_popup_height','500',0),
(2475,0,'config','config_image_popup_width','500',0),
(2474,0,'config','config_image_thumb_height','228',0),
(2473,0,'config','config_image_thumb_width','228',0),
(2472,0,'config','config_image_category_height','80',0),
(2470,0,'config','config_icon','data/sachs.com.png',0),
(2471,0,'config','config_image_category_width','80',0),
(2469,0,'config','config_logo','data/ZF-Logo.jpg',0),
(2468,0,'config','config_return_status_id','2',0),
(2467,0,'config','config_return_id','0',0),
(2465,0,'config','config_affiliate_id','0',0),
(2466,0,'config','config_commission','5',0),
(2464,0,'config','config_stock_status_id','6',0),
(2462,0,'config','config_stock_warning','0',0),
(1594,0,'google_sitemap','google_sitemap_status','1',0),
(2463,0,'config','config_stock_checkout','0',0),
(2459,0,'config','config_order_status_id','1',0),
(2460,0,'config','config_complete_status_id','18',0),
(2523,0,'vqmod','update','24',0),
(2524,0,'vqmod','vqm_cache','../vqmod/vqcache/',0),
(2525,0,'vqmod','log_file','../vqmod/logs/',0),
(2526,0,'vqmod','log_size','20',0),
(2527,0,'vqmod','vqm_create','1',0),
(2528,0,'vqmod','vqm_backup','../vqmod/backups/',0),
(2529,0,'vqmod','vqm_backups','3',0),
(2530,0,'vqmod','text_height','250',0),
(2531,0,'vqmod','text_style','1',0),
(2532,0,'vqmod','show_trim','1',0),
(2533,0,'vqmod','show_regex','1',0),
(2534,0,'vqmod','show_info','1',0),
(2535,0,'vqmod','search_delay','800',0),
(2536,0,'vqmod','generate_html','0',0),
(2537,0,'vqmod','manual_css','			body {\n				font:80%/1 Verdana, Geneva, sans-serif;\n				color: #457000;\n			}\n			div {\n				width:950px;\n				padding: 6px;\n				margin: 20px;\n			}\n			#file {\n				height:100px;\n				font-size:24px;\n				margin-bottom: 0px;\n				background-color:#f2ffdd;\n				border:1px solid #86db00;\n				-webkit-border-radius: 7px 7px 7px 7px;\n				-moz-border-radius: 7px 7px 7px 7px;\n				-khtml-border-radius: 7px 7px 7px 7px;\n				border-radius: 7px 7px 7px 7px;\n				-webkit-box-shadow:4px 4px 5px #DDDDDD;\n				-moz-box-shadow:4px 4px 5px #DDDDDD;\n				box-shadow:4px 4px 5px #DDDDDD;\n			}\n			#author {\n				width:900px;\n				font-size:12px;\n			}\n			.infile {\n				cursor: pointer;\n				font-size:18px;\n				margin: 40px 20px 0px 20px;\n				background-color:#86db00;\n				border:1px solid #457000;\n				-webkit-border-radius: 7px 7px 0px 0px;\n				-moz-border-radius: 7px 7px 0px 0px;\n				-khtml-border-radius: 7px 7px 0px 0px;\n				border-radius: 7px 7px 0px 0px;\n				-webkit-box-shadow:4px 4px 5px #DDDDDD;\n				-moz-box-shadow:4px 4px 5px #DDDDDD;\n				box-shadow:4px 4px 5px #DDDDDD;\n			}\n			.newfiles {\n				font-size:18px;\n				margin: 40px 20px 20px 20px;\n				background-color:#86db00;\n				border:1px solid #457000;\n				-webkit-border-radius: 7px 7px 7px 7px;\n				-moz-border-radius: 7px 7px 7px 7px;\n				-khtml-border-radius: 7px 7px 7px 7px;\n				border-radius: 7px 7px 7px 7px;\n				-webkit-box-shadow:4px 4px 5px #DDDDDD;\n				-moz-box-shadow:4px 4px 5px #DDDDDD;\n				box-shadow:4px 4px 5px #DDDDDD;\n			}\n			.vqfile {\n				margin: 0px 20px 40px 20px;\n				background-color:#f2ffdd;\n				border:1px solid #86db00;\n				-webkit-border-radius: 0px 0px 7px 7px;\n				-moz-border-radius: 0px 0px 7px 7px;\n				-khtml-border-radius: 0px 0px 7px 7px;\n				border-radius: 0px 0px 7px 7px;\n				-webkit-box-shadow:4px 4px 5px #DDDDDD;\n				-moz-box-shadow:4px 4px 5px #DDDDDD;\n				box-shadow:4px 4px 5px #DDDDDD;\n			}\n			.search {\n				cursor: pointer;\n				width:890px;\n				margin-bottom: 0px;\n				background-color:#deffaa;\n				border:1px solid #457000;\n				border-bottom:0px;\n				-webkit-border-radius: 7px 7px 0px 0px;\n				-moz-border-radius: 7px 7px 0px 0px;\n				-khtml-border-radius: 7px 7px 0px 0px;\n				border-radius: 7px 7px 0px 0px;\n			}\n			.find {\n				color: #FFFFF;\n				width:890px;\n				margin: 0px 20px;\n				background-color:#deffaa;\n				border:1px solid #457000;\n				border-bottom:0px;\n				border-top:0px;\n			}\n			.find &gt; textarea {\n				width:885px;\n				height:20px;\n				background-color:#f2ffdd;\n			}\n			.action {\n				width:890px;\n				margin: 0px 20px;\n				background-color:#deffaa;\n				border:1px solid #457000;\n				border-bottom:0px;\n				border-top:0px;\n			}\n			.code {\n				width:890px;\n				margin: 0px 20px 40px 20px;\n				background-color:#deffaa;\n				border:1px solid #457000;\n				border-top:0px;\n				-webkit-border-radius: 0px 0px 7px 7px;\n				-moz-border-radius: 0px 0px 7px 7px;\n				-khtml-border-radius: 0px 0px 7px 7px;\n				border-radius: 0px 0px 7px 7px;\n			}\n			.code &gt; textarea {\n				width:885px;\n				height:240px;\n				margin-bottom: 20px;\n				background-color:#f2ffdd;\n			}\n',0),
(2461,0,'config','config_stock_display','0',0),
(2458,0,'config','config_invoice_prefix','INV-2012-00',0),
(2457,0,'config','config_order_edit','100',0),
(2456,0,'config','config_checkout_id','0',0),
(2455,0,'config','config_guest_checkout','1',0),
(2454,0,'config','config_cart_weight','0',0),
(2453,0,'config','config_account_id','0',0),
(2452,0,'config','config_customer_price','0',0),
(2451,0,'config','config_customer_group_display','a:1:{i:0;s:1:\"1\";}',1),
(2450,0,'config','config_customer_group_id','1',0),
(2449,0,'config','config_customer_online','0',0),
(2447,0,'config','config_tax_default','shipping',0),
(2448,0,'config','config_tax_customer','shipping',0),
(2444,0,'config','config_voucher_max','1000',0),
(2446,0,'config','config_vat','0',0),
(2445,0,'config','config_tax','0',0),
(2443,0,'config','config_voucher_min','1',0),
(2442,0,'config','config_download','0',0),
(2441,0,'config','config_review_status','0',0),
(2440,0,'config','config_product_count','0',0),
(2439,0,'config','config_admin_limit','20',0),
(2438,0,'config','config_catalog_limit','15',0),
(2436,0,'config','config_length_class_id','2',0),
(2437,0,'config','config_weight_class_id','1',0),
(2435,0,'config','config_currency_auto','0',0),
(2433,0,'config','config_admin_language','ru',0),
(2434,0,'config','config_currency','UAH',0),
(2432,0,'config','config_language','ru',0),
(2430,0,'config','config_country_id','220',0),
(2431,0,'config','config_zone_id','3485',0),
(2428,0,'config','config_template','sachs',0),
(2429,0,'config','config_layout_id','4',0),
(2427,0,'config','config_meta_description','',0),
(2426,0,'config','config_title','ZF - амортизаторы, стойки, пружины',0),
(2425,0,'config','config_fax','0623856484',0),
(2424,0,'config','config_telephone','0623856150',0),
(2423,0,'config','config_email','inbox@tesma.com.ua',0),
(2420,0,'config','config_name','sachs',0),
(2421,0,'config','config_owner','Кравцов Олег Геннадьевич',0),
(2422,0,'config','config_address','ул. Буслаева, 10\r\nУкраина, Донецк, 83007',0),
(2644,0,'category','category_module','a:6:{i:0;a:4:{s:9:\"layout_id\";s:1:\"3\";s:8:\"position\";s:11:\"column_left\";s:6:\"status\";s:1:\"1\";s:10:\"sort_order\";s:1:\"1\";}i:1;a:4:{s:9:\"layout_id\";s:1:\"8\";s:8:\"position\";s:11:\"column_left\";s:6:\"status\";s:1:\"1\";s:10:\"sort_order\";s:1:\"1\";}i:2;a:4:{s:9:\"layout_id\";s:1:\"1\";s:8:\"position\";s:11:\"column_left\";s:6:\"status\";s:1:\"1\";s:10:\"sort_order\";s:1:\"1\";}i:3;a:4:{s:9:\"layout_id\";s:2:\"11\";s:8:\"position\";s:11:\"column_left\";s:6:\"status\";s:1:\"1\";s:10:\"sort_order\";s:1:\"1\";}i:4;a:4:{s:9:\"layout_id\";s:1:\"5\";s:8:\"position\";s:11:\"column_left\";s:6:\"status\";s:1:\"1\";s:10:\"sort_order\";s:1:\"1\";}i:5;a:4:{s:9:\"layout_id\";s:1:\"2\";s:8:\"position\";s:11:\"column_left\";s:6:\"status\";s:1:\"1\";s:10:\"sort_order\";s:1:\"1\";}}',1),
(2583,0,'cashless','VAT','20',0),
(2584,0,'cashless','cashless_order_status_id','19',0),
(2585,0,'cashless','cashless_status','1',0),
(2586,0,'cashless','cashless_sort_order','2',0),
(2582,0,'cashless','supplier_info_2','Ідентифікаційний код:	38263013\r\nКерівник:			Кравцов Олег Геннадійович\r\nЮридична адреса:	83007 місто Донецьк, Київский р-н, вулиця Буслаєва, будинок 10\r\nР/Рах.	№26001051815782\r\nМФО		335496\r\nПАТ КБ ПРИВАТБАНК\r\n',0),
(2640,0,'prepay','payment_info','ПриватБанк ГРН № карты 5168 7420 6108 4012 (комиссия +1%)\r\n\r\nПУМБ ГРН № карты 4314 3723 0025 0392\r\n\r\nУниверсал Банк ГРН № счета 2620 4000 4429 31',0),
(2639,0,'prepay','prepay_description','Вы можете осуществить оплату на следующие карты:',0),
(2641,0,'prepay','prepay_order_status_id','18',0),
(2642,0,'prepay','prepay_status','1',0),
(2643,0,'prepay','prepay_sort_order','1',0),
(2844,0,'price_import','profile_yunik_sachs','a:20:{s:12:\"profile_name\";s:14:\"Юник Sachs\";s:8:\"currency\";s:1:\"4\";s:9:\"start_row\";s:1:\"2\";s:7:\"end_row\";s:0:\"\";s:8:\"discount\";s:2:\"40\";s:6:\"margin\";s:2:\"30\";s:3:\"sku\";s:1:\"2\";s:11:\"sku_replace\";s:0:\"\";s:11:\"description\";s:1:\"3\";s:19:\"description_default\";s:0:\"\";s:19:\"description_replace\";s:33:\"Амортизатор@аморт\";s:8:\"quantity\";s:0:\"\";s:16:\"quantity_default\";s:1:\"5\";s:16:\"quantity_replace\";s:0:\"\";s:11:\"manufacture\";s:0:\"\";s:19:\"manufacture_default\";s:2:\"20\";s:19:\"manufacture_replace\";s:0:\"\";s:5:\"price\";s:1:\"4\";s:13:\"price_replace\";s:0:\"\";s:12:\"cache_method\";s:20:\"cache_in_memory_gzip\";}',0),
(2845,0,'price_import','profile_wix','a:24:{s:12:\"profile_name\";s:3:\"WIX\";s:8:\"currency\";s:1:\"4\";s:9:\"start_row\";s:2:\"12\";s:7:\"end_row\";s:3:\"324\";s:8:\"discount\";s:0:\"\";s:6:\"margin\";s:2:\"25\";s:3:\"sku\";s:1:\"3\";s:11:\"sku_replace\";s:0:\"\";s:11:\"description\";s:1:\"4\";s:19:\"description_default\";s:0:\"\";s:19:\"description_replace\";s:0:\"\";s:8:\"quantity\";s:0:\"\";s:16:\"quantity_default\";s:1:\"1\";s:16:\"quantity_replace\";s:0:\"\";s:11:\"manufacture\";s:0:\"\";s:19:\"manufacture_default\";s:3:\"228\";s:19:\"manufacture_replace\";s:0:\"\";s:5:\"price\";s:2:\"14\";s:13:\"price_replace\";s:0:\"\";s:12:\"cache_method\";s:20:\"cache_in_memory_gzip\";s:14:\"apc_cache_time\";s:3:\"600\";s:15:\"memcache_server\";s:9:\"localhost\";s:13:\"memcache_port\";s:5:\"11211\";s:19:\"memcache_cache_time\";s:3:\"600\";}',0)	;
#	TC`oc_stock_status`utf8_bin	;
CREATE TABLE `oc_stock_status` (
  `stock_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `language_id` int(11) NOT NULL,
  `name` varchar(32) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`stock_status_id`,`language_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=39	;
#	TD`oc_stock_status`utf8_bin	;
INSERT INTO `oc_stock_status` VALUES 
(7,2,'На складе'),
(8,2,'Предварительный заказ'),
(5,2,'Нет в наличии'),
(6,2,'Нет на складе'),
(4,2,'2 - 3 дня')	;
#	TC`oc_store`utf8_bin	;
CREATE TABLE `oc_store` (
  `store_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_bin NOT NULL,
  `url` varchar(255) COLLATE utf8_bin NOT NULL,
  `ssl` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`store_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_tax_class`utf8_bin	;
CREATE TABLE `oc_tax_class` (
  `tax_class_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `description` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`tax_class_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_tax_rate`utf8_bin	;
CREATE TABLE `oc_tax_rate` (
  `tax_rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `geo_zone_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(32) COLLATE utf8_bin NOT NULL,
  `rate` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `type` char(1) COLLATE utf8_bin NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`tax_rate_id`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TD`oc_tax_rate`utf8_bin	;
INSERT INTO `oc_tax_rate` VALUES 
(91,0,'Наша наценка',25.0000,'P','2013-09-13 17:13:19','2013-09-13 17:13:19')	;
#	TC`oc_tax_rate_to_customer_group`utf8_bin	;
CREATE TABLE `oc_tax_rate_to_customer_group` (
  `tax_rate_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  PRIMARY KEY (`tax_rate_id`,`customer_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TD`oc_tax_rate_to_customer_group`utf8_bin	;
INSERT INTO `oc_tax_rate_to_customer_group` VALUES 
(91,1)	;
#	TC`oc_tax_rule`utf8_bin	;
CREATE TABLE `oc_tax_rule` (
  `tax_rule_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_class_id` int(11) NOT NULL,
  `tax_rate_id` int(11) NOT NULL,
  `based` varchar(10) COLLATE utf8_bin NOT NULL,
  `priority` int(5) NOT NULL DEFAULT '1',
  PRIMARY KEY (`tax_rule_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
#	TC`oc_url_alias`utf8_bin	;
CREATE TABLE `oc_url_alias` (
  `url_alias_id` int(11) NOT NULL AUTO_INCREMENT,
  `query` varchar(255) COLLATE utf8_bin NOT NULL,
  `keyword` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`url_alias_id`),
  UNIQUE KEY `query` (`query`),
  KEY `keyword` (`keyword`)
) ENGINE=MyISAM AUTO_INCREMENT=4013 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=40	;
#	TD`oc_url_alias`utf8_bin	;
INSERT INTO `oc_url_alias` VALUES 
(1,'category_id=3','sachs'),
(2,'category_id=4','boge'),
(4011,'manufacturer_id=228','GROUPNAME'),
(4012,'manufacturer_id=229','sachs-s')	;
#	TC`oc_user`utf8_bin	;
CREATE TABLE `oc_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_group_id` int(11) NOT NULL,
  `username` varchar(20) COLLATE utf8_bin NOT NULL DEFAULT '',
  `password` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  `salt` varchar(9) COLLATE utf8_bin NOT NULL DEFAULT '',
  `firstname` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `lastname` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `email` varchar(96) COLLATE utf8_bin NOT NULL DEFAULT '',
  `code` varchar(32) COLLATE utf8_bin NOT NULL,
  `ip` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=128	;
#	TD`oc_user`utf8_bin	;
INSERT INTO `oc_user` VALUES 
(1,1,'admin','a99373d8b8c8d706048d173e0c523bb7fce8e213','88bf10903','Андрей','Ткаченко','root@tesma.com.ua','','127.0.0.2',1,'2012-10-02 13:24:49'),
(2,11,'jack','8e5e5be16f061c136a41755638878686222f8765','0ed731cbc','Евгений','Потапенко','','','212.66.40.18',1,'2012-11-15 11:34:04'),
(3,11,'igor','40773c95fa976567f9179daf65da70cf28d4d51e','bfa31ba9a','Игорь','Сагиров','','','212.66.40.18',1,'2012-11-19 12:11:35'),
(4,11,'mavr','c201027810e2aca90724d47afe1e6fe7509a1c03','7490b0211','Артем','Яценко','mavr@tesma.com.ua','','212.66.40.18',1,'2012-12-07 09:33:45')	;
#	TC`oc_user_group`utf8_bin	;
CREATE TABLE `oc_user_group` (
  `user_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_bin NOT NULL,
  `permission` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`user_group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=2846	;
#	TD`oc_user_group`utf8_bin	;
INSERT INTO `oc_user_group` VALUES 
(1,'Администратор','a:2:{s:6:\"access\";a:156:{i:0;s:14:\"amazon/listing\";i:1;s:14:\"amazon/product\";i:2;s:16:\"amazonus/listing\";i:3;s:16:\"amazonus/product\";i:4;s:17:\"catalog/attribute\";i:5;s:23:\"catalog/attribute_group\";i:6;s:16:\"catalog/category\";i:7;s:16:\"catalog/download\";i:8;s:14:\"catalog/filter\";i:9;s:19:\"catalog/information\";i:10;s:20:\"catalog/manufacturer\";i:11;s:14:\"catalog/option\";i:12;s:15:\"catalog/product\";i:13;s:15:\"catalog/profile\";i:14;s:14:\"catalog/review\";i:15;s:18:\"common/filemanager\";i:16;s:13:\"design/banner\";i:17;s:19:\"design/custom_field\";i:18;s:13:\"design/layout\";i:19;s:12:\"ebay/profile\";i:20;s:13:\"ebay/template\";i:21;s:14:\"extension/feed\";i:22;s:17:\"extension/manager\";i:23;s:16:\"extension/module\";i:24;s:17:\"extension/openbay\";i:25;s:17:\"extension/payment\";i:26;s:18:\"extension/shipping\";i:27;s:15:\"extension/total\";i:28;s:16:\"feed/google_base\";i:29;s:19:\"feed/google_sitemap\";i:30;s:20:\"localisation/country\";i:31;s:21:\"localisation/currency\";i:32;s:21:\"localisation/geo_zone\";i:33;s:21:\"localisation/language\";i:34;s:25:\"localisation/length_class\";i:35;s:25:\"localisation/order_status\";i:36;s:26:\"localisation/return_action\";i:37;s:26:\"localisation/return_reason\";i:38;s:26:\"localisation/return_status\";i:39;s:25:\"localisation/stock_status\";i:40;s:22:\"localisation/tax_class\";i:41;s:21:\"localisation/tax_rate\";i:42;s:25:\"localisation/weight_class\";i:43;s:17:\"localisation/zone\";i:44;s:14:\"module/account\";i:45;s:16:\"module/affiliate\";i:46;s:29:\"module/amazon_checkout_layout\";i:47;s:13:\"module/banner\";i:48;s:17:\"module/bestseller\";i:49;s:15:\"module/carousel\";i:50;s:15:\"module/category\";i:51;s:14:\"module/contact\";i:52;s:18:\"module/ebaydisplay\";i:53;s:15:\"module/featured\";i:54;s:13:\"module/filter\";i:55;s:18:\"module/google_talk\";i:56;s:18:\"module/information\";i:57;s:13:\"module/latest\";i:58;s:16:\"module/pp_layout\";i:59;s:19:\"module/price_import\";i:60;s:16:\"module/slideshow\";i:61;s:14:\"module/special\";i:62;s:12:\"module/store\";i:63;s:14:\"module/welcome\";i:64;s:14:\"openbay/amazon\";i:65;s:16:\"openbay/amazonus\";i:66;s:15:\"openbay/openbay\";i:67;s:12:\"openbay/play\";i:68;s:16:\"payment/alertpay\";i:69;s:23:\"payment/amazon_checkout\";i:70;s:24:\"payment/authorizenet_aim\";i:71;s:16:\"payment/cashless\";i:72;s:14:\"payment/cheque\";i:73;s:11:\"payment/cod\";i:74;s:21:\"payment/free_checkout\";i:75;s:18:\"payment/interkassa\";i:76;s:22:\"payment/klarna_account\";i:77;s:22:\"payment/klarna_invoice\";i:78;s:17:\"payment/klarna_pp\";i:79;s:14:\"payment/liqpay\";i:80;s:20:\"payment/moneybookers\";i:81;s:14:\"payment/nochex\";i:82;s:15:\"payment/paymate\";i:83;s:16:\"payment/paypoint\";i:84;s:13:\"payment/payza\";i:85;s:26:\"payment/perpetual_payments\";i:86;s:18:\"payment/pp_express\";i:87;s:25:\"payment/pp_payflow_iframe\";i:88;s:14:\"payment/pp_pro\";i:89;s:21:\"payment/pp_pro_iframe\";i:90;s:17:\"payment/pp_pro_pf\";i:91;s:17:\"payment/pp_pro_uk\";i:92;s:19:\"payment/pp_standard\";i:93;s:14:\"payment/prepay\";i:94;s:15:\"payment/sagepay\";i:95;s:22:\"payment/sagepay_direct\";i:96;s:18:\"payment/sagepay_us\";i:97;s:19:\"payment/twocheckout\";i:98;s:28:\"payment/web_payment_software\";i:99;s:16:\"payment/worldpay\";i:100;s:10:\"play/order\";i:101;s:12:\"play/product\";i:102;s:27:\"report/affiliate_commission\";i:103;s:22:\"report/customer_credit\";i:104;s:22:\"report/customer_online\";i:105;s:21:\"report/customer_order\";i:106;s:22:\"report/customer_reward\";i:107;s:24:\"report/product_purchased\";i:108;s:21:\"report/product_viewed\";i:109;s:18:\"report/sale_coupon\";i:110;s:17:\"report/sale_order\";i:111;s:18:\"report/sale_return\";i:112;s:20:\"report/sale_shipping\";i:113;s:15:\"report/sale_tax\";i:114;s:14:\"sale/affiliate\";i:115;s:12:\"sale/contact\";i:116;s:11:\"sale/coupon\";i:117;s:13:\"sale/customer\";i:118;s:20:\"sale/customer_ban_ip\";i:119;s:23:\"sale/customer_blacklist\";i:120;s:19:\"sale/customer_group\";i:121;s:10:\"sale/order\";i:122;s:14:\"sale/recurring\";i:123;s:11:\"sale/return\";i:124;s:12:\"sale/voucher\";i:125;s:18:\"sale/voucher_theme\";i:126;s:15:\"setting/setting\";i:127;s:13:\"setting/store\";i:128;s:16:\"shipping/auspost\";i:129;s:17:\"shipping/citylink\";i:130;s:17:\"shipping/delivery\";i:131;s:14:\"shipping/fedex\";i:132;s:13:\"shipping/flat\";i:133;s:13:\"shipping/free\";i:134;s:13:\"shipping/item\";i:135;s:23:\"shipping/parcelforce_48\";i:136;s:15:\"shipping/pickup\";i:137;s:19:\"shipping/royal_mail\";i:138;s:12:\"shipping/ups\";i:139;s:13:\"shipping/usps\";i:140;s:15:\"shipping/weight\";i:141;s:11:\"tool/backup\";i:142;s:14:\"tool/error_log\";i:143;s:12:\"total/coupon\";i:144;s:12:\"total/credit\";i:145;s:14:\"total/handling\";i:146;s:16:\"total/klarna_fee\";i:147;s:19:\"total/low_order_fee\";i:148;s:12:\"total/reward\";i:149;s:14:\"total/shipping\";i:150;s:15:\"total/sub_total\";i:151;s:9:\"total/tax\";i:152;s:11:\"total/total\";i:153;s:13:\"total/voucher\";i:154;s:9:\"user/user\";i:155;s:20:\"user/user_permission\";}s:6:\"modify\";a:156:{i:0;s:14:\"amazon/listing\";i:1;s:14:\"amazon/product\";i:2;s:16:\"amazonus/listing\";i:3;s:16:\"amazonus/product\";i:4;s:17:\"catalog/attribute\";i:5;s:23:\"catalog/attribute_group\";i:6;s:16:\"catalog/category\";i:7;s:16:\"catalog/download\";i:8;s:14:\"catalog/filter\";i:9;s:19:\"catalog/information\";i:10;s:20:\"catalog/manufacturer\";i:11;s:14:\"catalog/option\";i:12;s:15:\"catalog/product\";i:13;s:15:\"catalog/profile\";i:14;s:14:\"catalog/review\";i:15;s:18:\"common/filemanager\";i:16;s:13:\"design/banner\";i:17;s:19:\"design/custom_field\";i:18;s:13:\"design/layout\";i:19;s:12:\"ebay/profile\";i:20;s:13:\"ebay/template\";i:21;s:14:\"extension/feed\";i:22;s:17:\"extension/manager\";i:23;s:16:\"extension/module\";i:24;s:17:\"extension/openbay\";i:25;s:17:\"extension/payment\";i:26;s:18:\"extension/shipping\";i:27;s:15:\"extension/total\";i:28;s:16:\"feed/google_base\";i:29;s:19:\"feed/google_sitemap\";i:30;s:20:\"localisation/country\";i:31;s:21:\"localisation/currency\";i:32;s:21:\"localisation/geo_zone\";i:33;s:21:\"localisation/language\";i:34;s:25:\"localisation/length_class\";i:35;s:25:\"localisation/order_status\";i:36;s:26:\"localisation/return_action\";i:37;s:26:\"localisation/return_reason\";i:38;s:26:\"localisation/return_status\";i:39;s:25:\"localisation/stock_status\";i:40;s:22:\"localisation/tax_class\";i:41;s:21:\"localisation/tax_rate\";i:42;s:25:\"localisation/weight_class\";i:43;s:17:\"localisation/zone\";i:44;s:14:\"module/account\";i:45;s:16:\"module/affiliate\";i:46;s:29:\"module/amazon_checkout_layout\";i:47;s:13:\"module/banner\";i:48;s:17:\"module/bestseller\";i:49;s:15:\"module/carousel\";i:50;s:15:\"module/category\";i:51;s:14:\"module/contact\";i:52;s:18:\"module/ebaydisplay\";i:53;s:15:\"module/featured\";i:54;s:13:\"module/filter\";i:55;s:18:\"module/google_talk\";i:56;s:18:\"module/information\";i:57;s:13:\"module/latest\";i:58;s:16:\"module/pp_layout\";i:59;s:19:\"module/price_import\";i:60;s:16:\"module/slideshow\";i:61;s:14:\"module/special\";i:62;s:12:\"module/store\";i:63;s:14:\"module/welcome\";i:64;s:14:\"openbay/amazon\";i:65;s:16:\"openbay/amazonus\";i:66;s:15:\"openbay/openbay\";i:67;s:12:\"openbay/play\";i:68;s:16:\"payment/alertpay\";i:69;s:23:\"payment/amazon_checkout\";i:70;s:24:\"payment/authorizenet_aim\";i:71;s:16:\"payment/cashless\";i:72;s:14:\"payment/cheque\";i:73;s:11:\"payment/cod\";i:74;s:21:\"payment/free_checkout\";i:75;s:18:\"payment/interkassa\";i:76;s:22:\"payment/klarna_account\";i:77;s:22:\"payment/klarna_invoice\";i:78;s:17:\"payment/klarna_pp\";i:79;s:14:\"payment/liqpay\";i:80;s:20:\"payment/moneybookers\";i:81;s:14:\"payment/nochex\";i:82;s:15:\"payment/paymate\";i:83;s:16:\"payment/paypoint\";i:84;s:13:\"payment/payza\";i:85;s:26:\"payment/perpetual_payments\";i:86;s:18:\"payment/pp_express\";i:87;s:25:\"payment/pp_payflow_iframe\";i:88;s:14:\"payment/pp_pro\";i:89;s:21:\"payment/pp_pro_iframe\";i:90;s:17:\"payment/pp_pro_pf\";i:91;s:17:\"payment/pp_pro_uk\";i:92;s:19:\"payment/pp_standard\";i:93;s:14:\"payment/prepay\";i:94;s:15:\"payment/sagepay\";i:95;s:22:\"payment/sagepay_direct\";i:96;s:18:\"payment/sagepay_us\";i:97;s:19:\"payment/twocheckout\";i:98;s:28:\"payment/web_payment_software\";i:99;s:16:\"payment/worldpay\";i:100;s:10:\"play/order\";i:101;s:12:\"play/product\";i:102;s:27:\"report/affiliate_commission\";i:103;s:22:\"report/customer_credit\";i:104;s:22:\"report/customer_online\";i:105;s:21:\"report/customer_order\";i:106;s:22:\"report/customer_reward\";i:107;s:24:\"report/product_purchased\";i:108;s:21:\"report/product_viewed\";i:109;s:18:\"report/sale_coupon\";i:110;s:17:\"report/sale_order\";i:111;s:18:\"report/sale_return\";i:112;s:20:\"report/sale_shipping\";i:113;s:15:\"report/sale_tax\";i:114;s:14:\"sale/affiliate\";i:115;s:12:\"sale/contact\";i:116;s:11:\"sale/coupon\";i:117;s:13:\"sale/customer\";i:118;s:20:\"sale/customer_ban_ip\";i:119;s:23:\"sale/customer_blacklist\";i:120;s:19:\"sale/customer_group\";i:121;s:10:\"sale/order\";i:122;s:14:\"sale/recurring\";i:123;s:11:\"sale/return\";i:124;s:12:\"sale/voucher\";i:125;s:18:\"sale/voucher_theme\";i:126;s:15:\"setting/setting\";i:127;s:13:\"setting/store\";i:128;s:16:\"shipping/auspost\";i:129;s:17:\"shipping/citylink\";i:130;s:17:\"shipping/delivery\";i:131;s:14:\"shipping/fedex\";i:132;s:13:\"shipping/flat\";i:133;s:13:\"shipping/free\";i:134;s:13:\"shipping/item\";i:135;s:23:\"shipping/parcelforce_48\";i:136;s:15:\"shipping/pickup\";i:137;s:19:\"shipping/royal_mail\";i:138;s:12:\"shipping/ups\";i:139;s:13:\"shipping/usps\";i:140;s:15:\"shipping/weight\";i:141;s:11:\"tool/backup\";i:142;s:14:\"tool/error_log\";i:143;s:12:\"total/coupon\";i:144;s:12:\"total/credit\";i:145;s:14:\"total/handling\";i:146;s:16:\"total/klarna_fee\";i:147;s:19:\"total/low_order_fee\";i:148;s:12:\"total/reward\";i:149;s:14:\"total/shipping\";i:150;s:15:\"total/sub_total\";i:151;s:9:\"total/tax\";i:152;s:11:\"total/total\";i:153;s:13:\"total/voucher\";i:154;s:9:\"user/user\";i:155;s:20:\"user/user_permission\";}}'),
(10,'Demonstration',''),
(11,'Менеджеры','a:2:{s:6:\"access\";a:16:{i:0;s:16:\"catalog/category\";i:1;s:20:\"catalog/manufacturer\";i:2;s:15:\"catalog/product\";i:3;s:21:\"report/customer_order\";i:4;s:22:\"report/customer_reward\";i:5;s:24:\"report/product_purchased\";i:6;s:21:\"report/product_viewed\";i:7;s:17:\"report/sale_order\";i:8;s:18:\"report/sale_return\";i:9;s:20:\"report/sale_shipping\";i:10;s:15:\"report/sale_tax\";i:11;s:13:\"sale/customer\";i:12;s:23:\"sale/customer_blacklist\";i:13;s:19:\"sale/customer_group\";i:14;s:10:\"sale/order\";i:15;s:11:\"sale/return\";}s:6:\"modify\";a:5:{i:0;s:13:\"sale/customer\";i:1;s:23:\"sale/customer_blacklist\";i:2;s:19:\"sale/customer_group\";i:3;s:10:\"sale/order\";i:4;s:11:\"sale/return\";}}')	;
#	TC`oc_voucher`utf8_general_ci	;
CREATE TABLE `oc_voucher` (
  `voucher_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `code` varchar(10) NOT NULL,
  `from_name` varchar(64) NOT NULL,
  `from_email` varchar(96) NOT NULL,
  `to_name` varchar(64) NOT NULL,
  `to_email` varchar(96) NOT NULL,
  `voucher_theme_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`voucher_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_voucher_history`utf8_general_ci	;
CREATE TABLE `oc_voucher_history` (
  `voucher_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`voucher_history_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`oc_voucher_theme`utf8_general_ci	;
CREATE TABLE `oc_voucher_theme` (
  `voucher_theme_id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`voucher_theme_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8	;
#	TD`oc_voucher_theme`utf8_general_ci	;
INSERT INTO `oc_voucher_theme` VALUES 
(8,'data/demo/canon_eos_5d_2.jpg'),
(7,'data/demo/gift-voucher-birthday.jpg'),
(6,'data/demo/apple_logo.jpg')	;
#	TC`oc_voucher_theme_description`utf8_general_ci	;
CREATE TABLE `oc_voucher_theme_description` (
  `voucher_theme_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  PRIMARY KEY (`voucher_theme_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TD`oc_voucher_theme_description`utf8_general_ci	;
INSERT INTO `oc_voucher_theme_description` VALUES 
(6,2,'Christmas'),
(7,2,'Birthday'),
(8,2,'General')	;
#	TC`oc_weight_class`utf8_bin	;
CREATE TABLE `oc_weight_class` (
  `weight_class_id` int(11) NOT NULL AUTO_INCREMENT,
  `value` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  PRIMARY KEY (`weight_class_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=13	;
#	TD`oc_weight_class`utf8_bin	;
INSERT INTO `oc_weight_class` VALUES 
(1,1.00000000),
(2,1000.00000000),
(5,2.20460000),
(6,35.27400000)	;
#	TC`oc_weight_class_description`utf8_bin	;
CREATE TABLE `oc_weight_class_description` (
  `weight_class_id` int(11) NOT NULL AUTO_INCREMENT,
  `language_id` int(11) NOT NULL,
  `title` varchar(32) COLLATE utf8_bin NOT NULL,
  `unit` varchar(4) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`weight_class_id`,`language_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=34	;
#	TD`oc_weight_class_description`utf8_bin	;
INSERT INTO `oc_weight_class_description` VALUES 
(1,2,'Килограммы','кг'),
(2,2,'Граммы','г')	;
#	TC`oc_zone`utf8_bin	;
CREATE TABLE `oc_zone` (
  `zone_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` int(11) NOT NULL,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `code` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`zone_id`),
  KEY `country_id` (`country_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3506 DEFAULT CHARSET=utf8 COLLATE=utf8_bin AVG_ROW_LENGTH=53	;
#	TD`oc_zone`utf8_bin	;
INSERT INTO `oc_zone` VALUES 
(3480,220,'Черкасская область','CK',1),
(3481,220,'Черниговская область','CH',1),
(3482,220,'Черновицкая область','CV',1),
(3483,220,'АР Крым','CR',1),
(3484,220,'Днепропетровская область','DN',1),
(3485,220,'Донецкая область','DO',1),
(3486,220,'Ивано-Франковская область','IV',1),
(3487,220,'Харьковская область','KL',1),
(3488,220,'Хмельницкая область','KM',1),
(3489,220,'Кировоградская область','KR',1),
(3490,220,'Киевская область','KV',1),
(3492,220,'Луганская область','LU',1),
(3493,220,'Львовская область','LV',1),
(3494,220,'Николаевская область','MY',1),
(3495,220,'Одесская область','OD',1),
(3496,220,'Полтавская область','PO',1),
(3497,220,'Ровенская область','RI',1),
(3499,220,'Сумская область','SU',1),
(3500,220,'Тернопольская область','TE',1),
(3501,220,'Винницкая область','VI',1),
(3502,220,'Волынская область','VO',1),
(3503,220,'Закарпатская область','ZK',1),
(3504,220,'Запорожская область','ZA',1),
(3505,220,'Житомирская область','ZH',1)	;
#	TC`oc_zone_to_geo_zone`utf8_bin	;
CREATE TABLE `oc_zone_to_geo_zone` (
  `zone_to_geo_zone_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` int(11) NOT NULL,
  `zone_id` int(11) NOT NULL DEFAULT '0',
  `geo_zone_id` int(11) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`zone_to_geo_zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin	;
